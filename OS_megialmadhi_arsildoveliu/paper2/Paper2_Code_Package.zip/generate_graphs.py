#!/usr/bin/env python3
"""Generate all performance graphs for Paper 2."""
import json, os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

with open("/home/claude/paper2/results/results.json") as f:
    R = json.load(f)

OUT = "/home/claude/paper2/graphs"
os.makedirs(OUT, exist_ok=True)

C1="#1F3864"; C2="#2E75B6"; C3="#E6A817"; C4="#C00000"; C5="#2E8B57"
def save(fig, name):
    fig.tight_layout(pad=0.5)
    fig.savefig(f"{OUT}/{name}.png", dpi=160, bbox_inches='tight')
    plt.close(fig)
    print(f"  Saved: {name}.png")

plt.rcParams.update({'font.family':'sans-serif','font.size':9,'axes.spines.top':False,'axes.spines.right':False})

# ════════════════════════════════════════════════════════════════════════════
# FIG 1: PC — Throughput vs Buffer Size N
# ════════════════════════════════════════════════════════════════════════════
pc_n = [r for r in R["pc_c"] if r["vary"]=="N"]
ns   = [r["N"]          for r in pc_n]
tps  = [r["throughput"] for r in pc_n]

fig, axes = plt.subplots(1, 2, figsize=(10, 4))
fig.suptitle("Figure 1 — Producer-Consumer: Effect of Buffer Size N\n(M=2 producers, K=2 consumers, 40K items)", 
             fontsize=10, fontweight='bold', color=C1)

ax = axes[0]
ax.plot(ns, [t/1e6 for t in tps], "o-", color=C2, linewidth=2, markersize=7, label="C pthreads")
# Python Queue data (parsed from benchmark output)
py_ns  = [4, 8, 16, 32, 64]
py_tps = [243131, 314357, 367899, 395668, 365711]
ax.plot(py_ns, [t/1e6 for t in py_tps], "s--", color=C4, linewidth=2, markersize=7, label="Python Queue")
ax.set_xlabel("Buffer Size N"); ax.set_ylabel("Throughput (M items/sec)")
ax.set_title("Throughput vs Buffer Size")
ax.legend(); ax.grid(alpha=0.3); ax.set_xscale('log', base=2)

ax = axes[1]
ctx = [r["ctx_sw"] for r in pc_n]
ax.bar(range(len(ns)), ctx, color=[C2]*len(ns))
ax.set_xticks(range(len(ns))); ax.set_xticklabels([str(n) for n in ns])
ax.set_xlabel("Buffer Size N"); ax.set_ylabel("Context Switches")
ax.set_title("Context Switches vs Buffer Size\n(C pthreads)")
ax.grid(axis='y', alpha=0.3)
save(fig, "fig1_pc_buffer_size")

# ════════════════════════════════════════════════════════════════════════════
# FIG 2: PC — Throughput vs Producers M  &  vs Consumers K
# ════════════════════════════════════════════════════════════════════════════
pc_m = [r for r in R["pc_c"] if r["vary"]=="M"]
pc_k = [r for r in R["pc_c"] if r["vary"]=="K"]

ms_c = [r["M"] for r in pc_m]; tp_m_c = [r["throughput"] for r in pc_m]
ks_c = [r["K"] for r in pc_k]; tp_k_c = [r["throughput"] for r in pc_k]

# Python M data
py_ms  = [1, 2, 4, 6]
py_tp_m = [332889, 344569, 321872, 282676]

fig, axes = plt.subplots(1, 2, figsize=(10, 4))
fig.suptitle("Figure 2 — Producer-Consumer: Scalability with Thread Count\n(N=32 buffer size)", 
             fontsize=10, fontweight='bold', color=C1)

axes[0].plot(ms_c, [t/1e6 for t in tp_m_c], "o-", color=C2, lw=2, ms=7, label="C pthreads")
axes[0].plot(py_ms,[t/1e6 for t in py_tp_m], "s--",color=C4, lw=2, ms=7, label="Python Queue")
axes[0].set_xlabel("Number of Producers M"); axes[0].set_ylabel("Throughput (M items/sec)")
axes[0].set_title("Throughput vs Producers M\n(K=2 fixed)")
axes[0].legend(); axes[0].grid(alpha=0.3)

axes[1].plot(ks_c, [t/1e6 for t in tp_k_c], "o-", color=C2, lw=2, ms=7, label="C pthreads")
axes[1].set_xlabel("Number of Consumers K"); axes[1].set_ylabel("Throughput (M items/sec)")
axes[1].set_title("Throughput vs Consumers K\n(M=2 fixed)")
axes[1].legend(); axes[1].grid(alpha=0.3)
save(fig, "fig2_pc_scalability")

# ════════════════════════════════════════════════════════════════════════════
# FIG 3: PC — C vs Python comparison (wall time, latency)
# ════════════════════════════════════════════════════════════════════════════
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
fig.suptitle("Figure 3 — C pthreads vs Python: Performance Comparison\n(M=2, K=2, items=20K)", 
             fontsize=10, fontweight='bold', color=C1)

# Wall time comparison at different N
n_vals = [4,8,16,32,64]
c_walls   = [r["wall_ms"]   for r in R["pc_c"] if r["vary"]=="N"]
c_lat_p   = [r["lat_prod"]  for r in R["pc_c"] if r["vary"]=="N"]
py_walls  = [41.1, 31.8, 27.2, 25.3, 27.3]
py_lat_p  = [0.0079, 0.0061, 0.0051, 0.0048, 0.0051]

x = np.arange(len(n_vals)); w = 0.35
axes[0].bar(x - w/2, c_walls,  w, color=C2, label="C pthreads", alpha=0.9)
axes[0].bar(x + w/2, py_walls, w, color=C4, label="Python", alpha=0.9)
axes[0].set_xticks(x); axes[0].set_xticklabels([str(n) for n in n_vals])
axes[0].set_xlabel("Buffer Size N"); axes[0].set_ylabel("Wall Time (ms)")
axes[0].set_title("Wall Time: C vs Python")
axes[0].legend(); axes[0].grid(axis='y', alpha=0.3)

axes[1].plot(n_vals, c_lat_p, "o-", color=C2, lw=2, ms=7, label="C pthreads")
axes[1].plot(n_vals, py_lat_p,"s--",color=C4, lw=2, ms=7, label="Python")
axes[1].set_xlabel("Buffer Size N"); axes[1].set_ylabel("Avg Producer Latency (ms)")
axes[1].set_title("Producer Wait Latency")
axes[1].legend(); axes[1].grid(alpha=0.3)
save(fig, "fig3_pc_c_vs_python")

# ════════════════════════════════════════════════════════════════════════════
# FIG 4: DP — Throughput vs N (all 3 C solutions)
# ════════════════════════════════════════════════════════════════════════════
def dp_extract(sol_name):
    rows = [r for r in R["dp_c"] if r["solution"]==sol_name]
    return [r["N"] for r in rows], [r["throughput"]/1e6 for r in rows], [r["wall_ms"] for r in rows]

N_rh, tp_rh, w_rh = dp_extract("ResourceHierarchy")
N_sem,tp_sem,w_sem = dp_extract("Semaphore")
N_mon,tp_mon,w_mon = dp_extract("Monitor")

fig, axes = plt.subplots(1, 2, figsize=(10, 4))
fig.suptitle("Figure 4 — Dining Philosophers (C pthreads): 3 Solutions vs N Philosophers",
             fontsize=10, fontweight='bold', color=C1)

axes[0].plot(N_rh, tp_rh, "o-", color=C2,  lw=2, ms=7, label="Resource Hierarchy")
axes[0].plot(N_sem,tp_sem,"s--",color=C4,  lw=2, ms=7, label="Semaphore")
axes[0].plot(N_mon,tp_mon,"^-.",color=C5,  lw=2, ms=7, label="Monitor")
axes[0].set_xlabel("N Philosophers"); axes[0].set_ylabel("Throughput (M meals/sec)")
axes[0].set_title("Throughput vs N Philosophers (C)")
axes[0].legend(); axes[0].grid(alpha=0.3)

axes[1].plot(N_rh, w_rh, "o-", color=C2,  lw=2, ms=7, label="Resource Hierarchy")
axes[1].plot(N_sem,w_sem,"s--",color=C4,  lw=2, ms=7, label="Semaphore")
axes[1].plot(N_mon,w_mon,"^-.",color=C5,  lw=2, ms=7, label="Monitor")
axes[1].set_xlabel("N Philosophers"); axes[1].set_ylabel("Wall Time (ms)")
axes[1].set_title("Wall Time vs N Philosophers (C)")
axes[1].legend(); axes[1].grid(alpha=0.3)
save(fig, "fig4_dp_c_solutions")

# ════════════════════════════════════════════════════════════════════════════
# FIG 5: DP — Python 3 solutions
# ════════════════════════════════════════════════════════════════════════════
def dp_py_extract(sol_name):
    rows = [r for r in R["dp_py"] if sol_name in r.get("solution","")]
    return [r["N"] for r in rows], [r["throughput"]/1e3 for r in rows], [r["wall_ms"] for r in rows]

pN_rh,ptp_rh,pw_rh   = dp_py_extract("ResourceHierarchy")
pN_sem,ptp_sem,pw_sem = dp_py_extract("Semaphore")
pN_mon,ptp_mon,pw_mon = dp_py_extract("Monitor")

fig, axes = plt.subplots(1, 2, figsize=(10, 4))
fig.suptitle("Figure 5 — Dining Philosophers (Python): 3 Solutions vs N Philosophers",
             fontsize=10, fontweight='bold', color=C1)

if pN_rh:
    axes[0].plot(pN_rh, ptp_rh, "o-", color=C2,  lw=2, ms=7, label="Resource Hierarchy")
if pN_sem:
    axes[0].plot(pN_sem,ptp_sem,"s--",color=C4,  lw=2, ms=7, label="Semaphore")
if pN_mon:
    axes[0].plot(pN_mon,ptp_mon,"^-.",color=C5,  lw=2, ms=7, label="Monitor")
axes[0].set_xlabel("N Philosophers"); axes[0].set_ylabel("Throughput (K meals/sec)")
axes[0].set_title("Throughput vs N Philosophers (Python)")
axes[0].legend(); axes[0].grid(alpha=0.3)

if pw_rh:
    axes[1].plot(pN_rh, pw_rh, "o-", color=C2,  lw=2, ms=7, label="Resource Hierarchy")
if pw_sem:
    axes[1].plot(pN_sem,pw_sem,"s--",color=C4,  lw=2, ms=7, label="Semaphore")
if pw_mon:
    axes[1].plot(pN_mon,pw_mon,"^-.",color=C5,  lw=2, ms=7, label="Monitor")
axes[1].set_xlabel("N Philosophers"); axes[1].set_ylabel("Wall Time (ms)")
axes[1].set_title("Wall Time vs N Philosophers (Python)")
axes[1].legend(); axes[1].grid(alpha=0.3)
save(fig, "fig5_dp_python")

# ════════════════════════════════════════════════════════════════════════════
# FIG 6: C vs Python DP comparison (throughput ratio)
# ════════════════════════════════════════════════════════════════════════════
ns_common = [3, 5, 8, 12, 16]
# Get C Monitor throughput for these N values
c_mon_tp = []
py_mon_tp = []
for n in ns_common:
    c_rows  = [r for r in R["dp_c"]  if r["N"]==n and r["solution"]=="Monitor"]
    py_rows = [r for r in R["dp_py"] if r["N"]==n and "Monitor" in r.get("solution","")]
    if c_rows:  c_mon_tp.append(c_rows[0]["throughput"]/1e6)
    else:       c_mon_tp.append(0)
    if py_rows: py_mon_tp.append(py_rows[0]["throughput"]/1e3)
    else:       py_mon_tp.append(0)

fig, axes = plt.subplots(1, 2, figsize=(10, 4))
fig.suptitle("Figure 6 — C pthreads vs Python: Dining Philosophers (Monitor Solution)",
             fontsize=10, fontweight='bold', color=C1)

axes[0].plot(ns_common, c_mon_tp,  "o-", color=C2, lw=2, ms=7, label="C (M meals/sec)")
ax2 = axes[0].twinx()
ax2.plot(ns_common, py_mon_tp, "s--", color=C4, lw=2, ms=7, label="Python (K meals/sec)")
axes[0].set_xlabel("N Philosophers")
axes[0].set_ylabel("C Throughput (M meals/sec)", color=C2)
ax2.set_ylabel("Python Throughput (K meals/sec)", color=C4)
axes[0].set_title("Throughput: C vs Python (Monitor)")
axes[0].grid(alpha=0.3)

# Ratio plot
ratio = [c/py*1000 if py > 0 else 0 for c,py in zip(c_mon_tp, py_mon_tp)]
axes[1].bar(ns_common, ratio, color=C2, alpha=0.8)
axes[1].set_xlabel("N Philosophers"); axes[1].set_ylabel("C/Python Speedup Ratio")
axes[1].set_title("C pthreads Speedup over Python\n(Monitor solution)")
axes[1].grid(axis='y', alpha=0.3)
for i,(n,r) in enumerate(zip(ns_common,ratio)):
    if r > 0: axes[1].text(n, r+0.1, f"{r:.0f}×", ha='center', fontsize=8, color=C1)
save(fig, "fig6_c_vs_python_dp")

# ════════════════════════════════════════════════════════════════════════════
# FIG 7: PC — CPU usage heatmap style (M × K)
# ════════════════════════════════════════════════════════════════════════════
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
fig.suptitle("Figure 7 — Producer-Consumer: CPU Usage & Latency Analysis",
             fontsize=10, fontweight='bold', color=C1)

# CPU usage vs M (producers)
ms_all = [r["M"] for r in R["pc_c"] if r["vary"]=="M"]
cpu_all= [r["cpu_usage_percent"] for r in R["pc_c"] if r["vary"]=="M"]
lat_prod=[r["lat_prod"] for r in R["pc_c"] if r["vary"]=="M"]
lat_cons=[r["lat_cons"] for r in R["pc_c"] if r["vary"]=="M"]

axes[0].bar(ms_all, cpu_all, color=C2, alpha=0.8, label="CPU %")
axes[0].set_xlabel("Number of Producers M"); axes[0].set_ylabel("CPU Usage (%)")
axes[0].set_title("CPU Usage vs Producer Count\n(C pthreads, K=2, N=32)")
axes[0].set_ylim(90, 101); axes[0].grid(axis='y', alpha=0.3)
for m, c in zip(ms_all, cpu_all): axes[0].text(m, c+0.05, f"{c:.1f}%", ha='center', fontsize=8)

axes[1].plot(ms_all, lat_prod, "o-", color=C2, lw=2, ms=7, label="Producer latency")
axes[1].plot(ms_all, lat_cons, "s--",color=C3, lw=2, ms=7, label="Consumer latency")
axes[1].set_xlabel("Number of Producers M"); axes[1].set_ylabel("Avg Wait Latency (ms)")
axes[1].set_title("Producer & Consumer Latency vs M\n(C pthreads, K=2, N=32)")
axes[1].legend(); axes[1].grid(alpha=0.3)
save(fig, "fig7_pc_cpu_latency")

# ════════════════════════════════════════════════════════════════════════════
# FIG 8: Dining Philosophers — All 3 solutions bar chart at N=5 and N=16
# ════════════════════════════════════════════════════════════════════════════
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
fig.suptitle("Figure 8 — Dining Philosophers: Solution Comparison at N=5 and N=16",
             fontsize=10, fontweight='bold', color=C1)

for ax_idx, (n_val, ax) in enumerate(zip([5, 16], axes)):
    c_rows = {r["solution"]:r for r in R["dp_c"] if r["N"]==n_val}
    sols = ["ResourceHierarchy", "Semaphore", "Monitor"]
    tps  = [c_rows.get(s,{}).get("throughput",0)/1e6 for s in sols]
    colors= [C2, C4, C5]
    bars = ax.bar(["Resource\nHierarchy","Semaphore","Monitor"], tps, color=colors, alpha=0.9)
    ax.set_ylabel("Throughput (M meals/sec)")
    ax.set_title(f"C pthreads — N={n_val} Philosophers")
    ax.grid(axis='y', alpha=0.3)
    for bar, tp in zip(bars, tps):
        if tp > 0: ax.text(bar.get_x()+bar.get_width()/2, tp+0.02, f"{tp:.1f}M", ha='center', fontsize=8)
save(fig, "fig8_dp_solution_comparison")

# ════════════════════════════════════════════════════════════════════════════
# FIG 9: Summary comparison table as figure
# ════════════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(10, 3.5))
ax.axis('off')
fig.patch.set_facecolor("#F7F9FC")
ax.set_facecolor("#F7F9FC")
ax.set_title("Figure 9 — Complete Performance Summary: C pthreads vs Python",
             fontsize=10, fontweight='bold', color=C1, pad=10)

headers = ["Problem", "Config", "C pthreads", "Python", "C/Py Ratio", "Key Metric"]
data = [
    ["Prod-Cons", "M=2,K=2,N=64", "3.27M items/s", "366K items/s", "8.9×", "Throughput"],
    ["Prod-Cons", "M=2,K=2,N=4",  "606K items/s",  "243K items/s", "2.5×", "Throughput"],
    ["Prod-Cons Latency", "N=32", "0.001ms/item", "0.005ms/item", "5×",  "Producer wait"],
    ["Dining (Monitor)", "N=5",  "2.85M meals/s", "620K meals/s", "4.6×","Throughput"],
    ["Dining (Monitor)", "N=16", "2.60M meals/s", "596K meals/s", "4.4×","Throughput"],
    ["Dining Deadlock",  "All N","Zero (all 3)", "Zero (all 3)", "=",   "Safety"],
]
col_widths = [0.18, 0.15, 0.17, 0.17, 0.12, 0.17]
x_starts = [0.01]
for w in col_widths[:-1]: x_starts.append(x_starts[-1]+w)

y_header = 0.90
for j,(h,w,x) in enumerate(zip(headers,col_widths,x_starts)):
    ax.add_patch(plt.Rectangle((x,y_header-0.10),w,0.13,transform=ax.transAxes,
        color=C1,clip_on=False))
    ax.text(x+w/2,y_header+0.015,h,transform=ax.transAxes,ha='center',va='center',
        fontsize=8,fontweight='bold',color='white',clip_on=False)

for i, row in enumerate(data):
    y = y_header - 0.10 - i * 0.12
    bg = "#EBF3FB" if i % 2 == 0 else "#FFFFFF"
    for j,(cell,w,x) in enumerate(zip(row,col_widths,x_starts)):
        ax.add_patch(plt.Rectangle((x,y-0.09),w,0.11,transform=ax.transAxes,
            color=bg,clip_on=False,linewidth=0.5,edgecolor="#AAAAAA"))
        color = C4 if "×" in cell and cell != "=" else "#222222"
        ax.text(x+w/2,y-0.035,cell,transform=ax.transAxes,ha='center',va='center',
            fontsize=7.5,color=color,clip_on=False)

save(fig, "fig9_summary_table")

print("\nAll 9 figures generated successfully.")
