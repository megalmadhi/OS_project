"""
producer_consumer.py
Python threading implementation of the Bounded Buffer Producer-Consumer problem.
Paper 2 — Multithreaded Synchronization & Performance

Three synchronization variants:
  1. threading.Queue  (standard library, optimized)
  2. Manual mutex + condition variables (mirrors pthreads approach)
  3. Semaphore-based (classic textbook approach)

Usage:
  python3 producer_consumer.py [producers] [consumers] [buffer_size] [items_per_producer] [variant]
"""

import threading
import queue
import time
import sys
import os
from collections import deque

# ── Variant 1: threading.Queue (reference implementation) ────────────────
def run_queue_variant(M, K, N, items_per_producer):
    """Uses Python's thread-safe Queue — the production-quality approach."""
    buf = queue.Queue(maxsize=N)
    total_items = M * items_per_producer
    items_per_consumer = total_items // K

    produced = [0]
    consumed = [0]
    prod_wait = [0.0]
    cons_wait = [0.0]
    lock = threading.Lock()

    def producer(pid):
        for i in range(items_per_producer):
            t0 = time.perf_counter()
            buf.put(pid * 100000 + i)   # blocks if full
            with lock:
                prod_wait[0] += time.perf_counter() - t0
                produced[0] += 1

    def consumer(cid):
        for _ in range(items_per_consumer):
            t0 = time.perf_counter()
            buf.get()                    # blocks if empty
            with lock:
                cons_wait[0] += time.perf_counter() - t0
                consumed[0] += 1

    t_start = time.perf_counter()
    threads = []
    for i in range(M): threads.append(threading.Thread(target=producer, args=(i,)))
    for i in range(K): threads.append(threading.Thread(target=consumer, args=(i,)))
    for t in threads: t.start()
    for t in threads: t.join()
    wall_ms = (time.perf_counter() - t_start) * 1000

    avg_prod_lat = (prod_wait[0] / produced[0] * 1000) if produced[0] > 0 else 0
    avg_cons_lat = (cons_wait[0] / consumed[0] * 1000) if consumed[0] > 0 else 0
    throughput   = total_items / (wall_ms / 1000)
    return wall_ms, throughput, avg_prod_lat, avg_cons_lat

# ── Variant 2: Manual mutex + condition variables ─────────────────────────
class BoundedBuffer:
    """Manual bounded buffer mirroring the C pthreads implementation."""
    def __init__(self, capacity):
        self.capacity  = capacity
        self.buf       = deque()
        self.lock      = threading.Lock()
        self.not_full  = threading.Condition(self.lock)
        self.not_empty = threading.Condition(self.lock)
        self.ctx_sw    = 0

    def put(self, item):
        with self.not_full:
            while len(self.buf) == self.capacity:
                self.ctx_sw += 1
                self.not_full.wait()
            self.buf.append(item)
            self.not_empty.notify()

    def get(self):
        with self.not_empty:
            while len(self.buf) == 0:
                self.ctx_sw += 1
                self.not_empty.wait()
            item = self.buf.popleft()
            self.not_full.notify()
            return item

def run_manual_variant(M, K, N, items_per_producer):
    """Manual condition-variable synchronization."""
    buf = BoundedBuffer(N)
    total_items = M * items_per_producer
    items_per_consumer = total_items // K

    prod_wait = [0.0]; cons_wait = [0.0]; lock = threading.Lock()

    def producer(pid):
        for i in range(items_per_producer):
            t0 = time.perf_counter()
            buf.put(pid * 100000 + i)
            with lock: prod_wait[0] += time.perf_counter() - t0

    def consumer(cid):
        for _ in range(items_per_consumer):
            t0 = time.perf_counter()
            buf.get()
            with lock: cons_wait[0] += time.perf_counter() - t0

    t_start = time.perf_counter()
    threads = []
    for i in range(M): threads.append(threading.Thread(target=producer, args=(i,)))
    for i in range(K): threads.append(threading.Thread(target=consumer, args=(i,)))
    for t in threads: t.start()
    for t in threads: t.join()
    wall_ms = (time.perf_counter() - t_start) * 1000

    avg_prod_lat = (prod_wait[0] / (M * items_per_producer) * 1000)
    avg_cons_lat = (cons_wait[0] / total_items * 1000)
    throughput   = total_items / (wall_ms / 1000)
    return wall_ms, throughput, avg_prod_lat, avg_cons_lat, buf.ctx_sw

# ── Variant 3: Semaphore-based ────────────────────────────────────────────
def run_semaphore_variant(M, K, N, items_per_producer):
    """Classic semaphore approach: mutex + empty + full semaphores."""
    mutex = threading.Semaphore(1)
    empty = threading.Semaphore(N)    # counts empty slots
    full  = threading.Semaphore(0)    # counts full slots
    buf   = [None] * N
    head  = [0]; tail = [0]
    total_items = M * items_per_producer
    items_per_consumer = total_items // K

    prod_wait = [0.0]; cons_wait = [0.0]; wlock = threading.Lock()

    def producer(pid):
        for i in range(items_per_producer):
            t0 = time.perf_counter()
            empty.acquire()
            mutex.acquire()
            dt = time.perf_counter() - t0
            buf[tail[0] % N] = pid * 100000 + i
            tail[0] += 1
            mutex.release()
            full.release()
            with wlock: prod_wait[0] += dt

    def consumer(cid):
        for _ in range(items_per_consumer):
            t0 = time.perf_counter()
            full.acquire()
            mutex.acquire()
            dt = time.perf_counter() - t0
            _ = buf[head[0] % N]
            head[0] += 1
            mutex.release()
            empty.release()
            with wlock: cons_wait[0] += dt

    t_start = time.perf_counter()
    threads = []
    for i in range(M): threads.append(threading.Thread(target=producer, args=(i,)))
    for i in range(K): threads.append(threading.Thread(target=consumer, args=(i,)))
    for t in threads: t.start()
    for t in threads: t.join()
    wall_ms = (time.perf_counter() - t_start) * 1000

    avg_prod_lat = (prod_wait[0] / (M * items_per_producer) * 1000)
    avg_cons_lat = (cons_wait[0] / total_items * 1000)
    throughput   = total_items / (wall_ms / 1000)
    return wall_ms, throughput, avg_prod_lat, avg_cons_lat

# ── Main ──────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    M     = int(sys.argv[1]) if len(sys.argv) > 1 else 2
    K     = int(sys.argv[2]) if len(sys.argv) > 2 else 2
    N     = int(sys.argv[3]) if len(sys.argv) > 3 else 16
    items = int(sys.argv[4]) if len(sys.argv) > 4 else 10000

    # Run all three variants
    w1,t1,lp1,lc1         = run_queue_variant(M, K, N, items)
    w2,t2,lp2,lc2,ctx     = run_manual_variant(M, K, N, items)
    w3,t3,lp3,lc3         = run_semaphore_variant(M, K, N, items)

    print(f"M={M} K={K} N={N} items={M*items}")
    print(f"  Queue:     wall={w1:.1f}ms  throughput={t1:.0f}/s  lat_p={lp1:.4f}ms lat_c={lc1:.4f}ms")
    print(f"  Manual:    wall={w2:.1f}ms  throughput={t2:.0f}/s  lat_p={lp2:.4f}ms lat_c={lc2:.4f}ms  ctx_sw={ctx}")
    print(f"  Semaphore: wall={w3:.1f}ms  throughput={t3:.0f}/s  lat_p={lp3:.4f}ms lat_c={lc3:.4f}ms")
