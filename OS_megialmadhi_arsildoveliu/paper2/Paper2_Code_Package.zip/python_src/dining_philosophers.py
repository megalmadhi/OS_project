"""
dining_philosophers.py
Python threading implementation — THREE synchronization solutions:
  1. Resource Hierarchy (lower fork first)
  2. Semaphore-based (room semaphore limits N-1 concurrent diners)
  3. Monitor-based (Tanenbaum state machine with condition variables)

Paper 2 — Multithreaded Synchronization & Performance
Usage: python3 dining_philosophers.py [N] [meals] [solution: 1|2|3|all]
"""

import threading
import time
import sys

# ── Solution 1: Resource Hierarchy ────────────────────────────────────────
def dining_resource_hierarchy(N, meals):
    forks = [threading.Lock() for _ in range(N)]
    total_wait = [0.0]
    lock = threading.Lock()

    def philosopher(i):
        left, right = i, (i + 1) % N
        first  = min(left, right)
        second = max(left, right)
        for _ in range(meals):
            t0 = time.perf_counter()
            forks[first].acquire()
            forks[second].acquire()
            dt = time.perf_counter() - t0
            with lock: total_wait[0] += dt
            # Eat
            forks[second].release()
            forks[first].release()

    t_start = time.perf_counter()
    threads = [threading.Thread(target=philosopher, args=(i,)) for i in range(N)]
    for t in threads: t.start()
    for t in threads: t.join()
    wall_ms = (time.perf_counter() - t_start) * 1000
    avg_wait_ms = (total_wait[0] / (N * meals)) * 1000
    throughput  = (N * meals) / (wall_ms / 1000)
    return wall_ms, throughput, avg_wait_ms

# ── Solution 2: Semaphore-based (room semaphore) ───────────────────────────
def dining_semaphore(N, meals):
    import threading
    forks = [threading.Semaphore(1) for _ in range(N)]
    room  = threading.Semaphore(N - 1)   # allow at most N-1 simultaneous
    total_wait = [0.0]
    lock = threading.Lock()

    def philosopher(i):
        left, right = i, (i + 1) % N
        for _ in range(meals):
            t0 = time.perf_counter()
            room.acquire()
            forks[left].acquire()
            forks[right].acquire()
            dt = time.perf_counter() - t0
            with lock: total_wait[0] += dt
            # Eat
            forks[right].release()
            forks[left].release()
            room.release()

    t_start = time.perf_counter()
    threads = [threading.Thread(target=philosopher, args=(i,)) for i in range(N)]
    for t in threads: t.start()
    for t in threads: t.join()
    wall_ms = (time.perf_counter() - t_start) * 1000
    avg_wait_ms = (total_wait[0] / (N * meals)) * 1000
    throughput  = (N * meals) / (wall_ms / 1000)
    return wall_ms, throughput, avg_wait_ms

# ── Solution 3: Monitor-based (Tanenbaum) ─────────────────────────────────
class DiningMonitor:
    """Monitor implementing the classic Tanenbaum state-machine solution."""
    THINKING = 0; HUNGRY = 1; EATING = 2

    def __init__(self, N):
        self.N     = N
        self.state = [self.THINKING] * N
        self.lock  = threading.Lock()
        self.cond  = [threading.Condition(self.lock) for _ in range(N)]

    def _test(self, i):
        if (self.state[i] == self.HUNGRY and
            self.state[(i - 1) % self.N] != self.EATING and
            self.state[(i + 1) % self.N] != self.EATING):
            self.state[i] = self.EATING
            self.cond[i].notify()

    def pickup(self, i):
        with self.lock:
            self.state[i] = self.HUNGRY
            self._test(i)
            while self.state[i] != self.EATING:
                self.cond[i].wait()

    def putdown(self, i):
        with self.lock:
            self.state[i] = self.THINKING
            self._test((i - 1) % self.N)
            self._test((i + 1) % self.N)

def dining_monitor(N, meals):
    monitor = DiningMonitor(N)
    total_wait = [0.0]
    lock = threading.Lock()

    def philosopher(i):
        for _ in range(meals):
            t0 = time.perf_counter()
            monitor.pickup(i)
            dt = time.perf_counter() - t0
            with lock: total_wait[0] += dt
            # Eat
            monitor.putdown(i)

    t_start = time.perf_counter()
    threads = [threading.Thread(target=philosopher, args=(i,)) for i in range(N)]
    for t in threads: t.start()
    for t in threads: t.join()
    wall_ms = (time.perf_counter() - t_start) * 1000
    avg_wait_ms = (total_wait[0] / (N * meals)) * 1000
    throughput  = (N * meals) / (wall_ms / 1000)
    return wall_ms, throughput, avg_wait_ms

# ── Main ──────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    N     = int(sys.argv[1]) if len(sys.argv) > 1 else 5
    meals = int(sys.argv[2]) if len(sys.argv) > 2 else 500
    sol   = sys.argv[3] if len(sys.argv) > 3 else "all"

    names = {1: "ResourceHierarchy", 2: "Semaphore", 3: "Monitor"}
    fns   = {1: dining_resource_hierarchy, 2: dining_semaphore, 3: dining_monitor}

    if sol == "all":
        for s in [1, 2, 3]:
            w, tp, aw = fns[s](N, meals)
            print(f"solution={names[s]:20s} N={N} meals={meals} "
                  f"wall={w:.1f}ms throughput={tp:.0f}meals/s avg_wait={aw:.4f}ms")
    else:
        s = int(sol)
        w, tp, aw = fns[s](N, meals)
        print(f"solution={names[s]} N={N} meals={meals} "
              f"wall={w:.1f}ms throughput={tp:.0f}meals/s avg_wait={aw:.4f}ms")
