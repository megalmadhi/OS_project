#!/usr/bin/env python3
"""
run_benchmarks.py
Runs all Paper 2 experiments and saves results as JSON + CSV
"""
import subprocess, json, time, os, sys, csv

C_PC  = "/home/claude/paper2/c_src/producer_consumer"
C_DP  = "/home/claude/paper2/c_src/dining_philosophers"
PY_PC = "/home/claude/paper2/python_src/producer_consumer.py"
PY_DP = "/home/claude/paper2/python_src/dining_philosophers.py"
OUT   = "/home/claude/paper2/results"
os.makedirs(OUT, exist_ok=True)

results = {"pc_c": [], "pc_py": [], "dp_c": [], "dp_py": []}

def run(cmd, label=""):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        out = r.stdout.strip()
        if out: print(f"  {label}: {out[:120]}")
        return out
    except Exception as e:
        print(f"  ERROR {label}: {e}")
        return ""

print("=" * 60)
print("PAPER 2 — BENCHMARK SUITE")
print("=" * 60)

# ── 1. Producer-Consumer: vary buffer size N ─────────────────────────────
print("\n[PC-1] C pthreads: varying buffer size N (M=2, K=2)")
for N in [4, 8, 16, 32, 64, 128]:
    out = run([C_PC, "2", "2", str(N), "20000"], f"N={N}")
    if out:
        parts = dict(p.split("=") for p in out.split() if "=" in p)
        results["pc_c"].append({
            "M":2,"K":2,"N":N,"vary":"N",
            "wall_ms": float(parts.get("wall","0").replace("ms","")),
            "throughput": float(parts.get("throughput","0")),
            "lat_prod": float(parts.get("lat_prod","0").replace("ms","")),
            "lat_cons": float(parts.get("lat_cons","0").replace("ms","")),
            "ctx_sw": int(parts.get("ctx_sw","0")),
        })

print("\n[PC-2] C pthreads: varying producers M (K=2, N=32)")
for M in [1, 2, 4, 6, 8]:
    out = run([C_PC, str(M), "2", "32", "10000"], f"M={M}")
    if out:
        parts = dict(p.split("=") for p in out.split() if "=" in p)
        results["pc_c"].append({
            "M":M,"K":2,"N":32,"vary":"M",
            "wall_ms": float(parts.get("wall","0").replace("ms","")),
            "throughput": float(parts.get("throughput","0")),
            "lat_prod": float(parts.get("lat_prod","0").replace("ms","")),
            "lat_cons": float(parts.get("lat_cons","0").replace("ms","")),
            "ctx_sw": int(parts.get("ctx_sw","0")),
        })

print("\n[PC-3] C pthreads: varying consumers K (M=2, N=32)")
for K in [1, 2, 4, 6, 8]:
    out = run([C_PC, "2", str(K), "32", "10000"], f"K={K}")
    if out:
        parts = dict(p.split("=") for p in out.split() if "=" in p)
        results["pc_c"].append({
            "M":2,"K":K,"N":32,"vary":"K",
            "wall_ms": float(parts.get("wall","0").replace("ms","")),
            "throughput": float(parts.get("throughput","0")),
            "lat_prod": float(parts.get("lat_prod","0").replace("ms","")),
            "lat_cons": float(parts.get("lat_cons","0").replace("ms","")),
            "ctx_sw": int(parts.get("ctx_sw","0")),
        })

print("\n[PC-4] Python: varying buffer size N (M=2, K=2)")
for N in [4, 8, 16, 32, 64]:
    out = run(["python3", PY_PC, "2", "2", str(N), "5000"], f"N={N}")
    if out:
        for line in out.split("\n"):
            if "Queue:" in line:
                parts = line.split()
                w = float(parts[1].split("=")[1].replace("ms",""))
                t = float(parts[2].split("=")[1].replace("/s",""))
                results["pc_py"].append({"N":N,"M":2,"K":2,"vary":"N","variant":"Queue",
                    "wall_ms":w,"throughput":t})
            if "Manual:" in line:
                parts = line.split()
                w = float(parts[1].split("=")[1].replace("ms",""))
                t = float(parts[2].split("=")[1].replace("/s",""))
                results["pc_py"].append({"N":N,"M":2,"K":2,"vary":"N","variant":"Manual",
                    "wall_ms":w,"throughput":t})

print("\n[PC-5] Python: varying producers M (K=2, N=16)")
for M in [1, 2, 4, 6]:
    out = run(["python3", PY_PC, str(M), "2", "16", "5000"], f"M={M}")
    if out:
        for line in out.split("\n"):
            if "Queue:" in line:
                parts = line.split()
                w = float(parts[1].split("=")[1].replace("ms",""))
                t = float(parts[2].split("=")[1].replace("/s",""))
                results["pc_py"].append({"N":16,"M":M,"K":2,"vary":"M","variant":"Queue",
                    "wall_ms":w,"throughput":t})

# ── 2. Dining Philosophers ────────────────────────────────────────────────
print("\n[DP-1] C: all 3 solutions, varying N philosophers")
for N in [3, 5, 8, 12, 16, 24, 32]:
    for sol in [1, 2, 3]:
        meals = max(100, 2000 // N)
        out = run([C_DP, str(N), str(meals), str(sol)], f"N={N} sol={sol}")
        if out:
            parts = dict(p.split("=") for p in out.split() if "=" in p)
            results["dp_c"].append({
                "solution": parts.get("solution",""),
                "N": N, "meals": meals,
                "wall_ms": float(parts.get("wall","0").replace("ms","")),
                "throughput": float(parts.get("throughput","0").replace("meals/s","")),
                "avg_wait": float(parts.get("avg_wait","0").replace("ms","")),
            })

print("\n[DP-2] Python: all 3 solutions, varying N philosophers")
for N in [3, 5, 8, 12, 16]:
    meals = max(50, 500 // N)
    out = run(["python3", PY_DP, str(N), str(meals), "all"], f"N={N}")
    if out:
        for line in out.split("\n"):
            if "solution=" in line:
                parts = dict(p.split("=") for p in line.split() if "=" in p)
                results["dp_py"].append({
                    "solution": parts.get("solution",""),
                    "N": N, "meals": meals,
                    "wall_ms": float(parts.get("wall","0").replace("ms","")),
                    "throughput": float(parts.get("throughput","0").replace("meals/s","")),
                    "avg_wait": float(parts.get("avg_wait","0").replace("ms","")),
                })

# ── Save results ──────────────────────────────────────────────────────────
with open(f"{OUT}/results.json", "w") as f:
    json.dump(results, f, indent=2)
print(f"\nSaved: {OUT}/results.json")

# Save CSV
with open(f"{OUT}/pc_c.csv", "w", newline="") as f:
    if results["pc_c"]:
        w = csv.DictWriter(f, fieldnames=results["pc_c"][0].keys())
        w.writeheader(); w.writerows(results["pc_c"])

with open(f"{OUT}/dp_c.csv", "w", newline="") as f:
    if results["dp_c"]:
        w = csv.DictWriter(f, fieldnames=results["dp_c"][0].keys())
        w.writeheader(); w.writerows(results["dp_c"])

print(f"Saved CSVs to {OUT}/")
print("\n=== BENCHMARK COMPLETE ===")
print(f"PC C results:  {len(results['pc_c'])}")
print(f"PC Py results: {len(results['pc_py'])}")
print(f"DP C results:  {len(results['dp_c'])}")
print(f"DP Py results: {len(results['dp_py'])}")
