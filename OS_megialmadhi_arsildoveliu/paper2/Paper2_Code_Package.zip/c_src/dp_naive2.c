#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <signal.h>
#include <string.h>

#define MAX_PHIL 32
int N_PHIL, MEALS;
pthread_mutex_t forks[MAX_PHIL];
volatile int meals_done = 0;

void *naive_phil(void *arg) {
    int id = *(int *)arg;
    int left = id, right = (id + 1) % N_PHIL;
    for (int m = 0; m < MEALS; m++) {
        struct timespec ts = {0, 100000000LL}; // 100ms timeout per lock attempt
        // Try left fork
        if (pthread_mutex_trylock(&forks[left]) != 0) {
            nanosleep(&ts, NULL);
            if (pthread_mutex_trylock(&forks[left]) != 0) return NULL;
        }
        // Try right fork
        if (pthread_mutex_trylock(&forks[right]) != 0) {
            pthread_mutex_unlock(&forks[left]);
            nanosleep(&ts, NULL);
            continue;  // retry
        }
        // eat
        pthread_mutex_unlock(&forks[right]);
        pthread_mutex_unlock(&forks[left]);
        __sync_fetch_and_add(&meals_done, 1);
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    N_PHIL = argc>=2 ? atoi(argv[1]) : 5;
    MEALS  = argc>=3 ? atoi(argv[2]) : 200;
    int trials = argc>=4 ? atoi(argv[3]) : 10;
    int deadlocks = 0;

    for (int t = 0; t < trials; t++) {
        meals_done = 0;
        for (int i = 0; i < N_PHIL; i++) pthread_mutex_init(&forks[i], NULL);
        pthread_t threads[MAX_PHIL];
        int ids[MAX_PHIL];
        for (int i = 0; i < N_PHIL; i++) { ids[i]=i; }
        for (int i = 0; i < N_PHIL; i++)
            pthread_create(&threads[i], NULL, naive_phil, &ids[i]);
        // Wait 400ms max
        struct timespec sleep_t = {0, 400000000LL};
        nanosleep(&sleep_t, NULL);
        int expected = N_PHIL * MEALS;
        // Check if all meals done
        for (int i = 0; i < N_PHIL; i++) pthread_detach(threads[i]);
        if (meals_done < expected * 0.95) deadlocks++;
        for (int i = 0; i < N_PHIL; i++) pthread_mutex_destroy(&forks[i]);
    }
    printf("N=%d meals=%d trials=%d deadlocks=%d freq=%.0f%%\n",
           N_PHIL, MEALS, trials, deadlocks, 100.0*deadlocks/trials);
    return 0;
}
