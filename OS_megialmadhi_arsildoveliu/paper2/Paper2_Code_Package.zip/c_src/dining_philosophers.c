/*
 * dining_philosophers.c
 * POSIX Pthreads implementation — THREE synchronization solutions:
 *   1. Resource Hierarchy (Dijkstra's ordering)
 *   2. Semaphore-based (Chandy/Misra variant)
 *   3. Monitor-based (condition variable state machine)
 *
 * Paper 2 — Multithreaded Synchronization & Performance
 * Compile: gcc -O2 -pthread -o dining_philosophers dining_philosophers.c -lm
 * Usage:   ./dining_philosophers <philosophers> <meals> <solution: 1|2|3>
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <time.h>
#include <string.h>

#define MAX_PHIL  64
#define NS_PER_MS 1000000LL
#define NS_PER_S  1000000000LL

typedef enum { THINKING=0, HUNGRY=1, EATING=2 } PhilState;

/* ── Shared state ──────────────────────────────────────────────────────── */
int          N_PHIL;
int          MEALS_PER_PHIL;
long long    total_wait_ns;       /* cumulative hungry→eating wait */
int          deadlock_count;
pthread_mutex_t stat_lock = PTHREAD_MUTEX_INITIALIZER;

static long long now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * NS_PER_S + ts.tv_nsec;
}

/* ═══════════════════════════════════════════════════════════════════════════
   SOLUTION 1: Resource Hierarchy (Dijkstra)
   Each philosopher picks up the lower-numbered fork first.
   ═══════════════════════════════════════════════════════════════════════════ */
pthread_mutex_t rh_forks[MAX_PHIL];

void *rh_philosopher(void *arg) {
    int id = *(int *)arg;
    int left  = id;
    int right = (id + 1) % N_PHIL;
    int first = (left < right) ? left : right;
    int second = (left < right) ? right : left;

    for (int m = 0; m < MEALS_PER_PHIL; m++) {
        /* Think */
        /* Hungry — pick up lower fork first */
        long long hungry_at = now_ns();
        pthread_mutex_lock(&rh_forks[first]);
        pthread_mutex_lock(&rh_forks[second]);
        long long eating_at = now_ns();

        pthread_mutex_lock(&stat_lock);
        total_wait_ns += (eating_at - hungry_at);
        pthread_mutex_unlock(&stat_lock);

        /* Eat */

        /* Put down forks */
        pthread_mutex_unlock(&rh_forks[second]);
        pthread_mutex_unlock(&rh_forks[first]);
    }
    return NULL;
}

/* ═══════════════════════════════════════════════════════════════════════════
   SOLUTION 2: Semaphore-based with a waiter (counting semaphore limits
   simultaneous diners to N-1, preventing circular deadlock)
   ═══════════════════════════════════════════════════════════════════════════ */
sem_t        sem_forks[MAX_PHIL];
sem_t        sem_room;           /* limits concurrent diners to N-1 */

void *sem_philosopher(void *arg) {
    int id    = *(int *)arg;
    int left  = id;
    int right = (id + 1) % N_PHIL;

    for (int m = 0; m < MEALS_PER_PHIL; m++) {
        long long hungry_at = now_ns();

        sem_wait(&sem_room);           /* enter dining room (max N-1) */
        sem_wait(&sem_forks[left]);    /* pick up left fork */
        sem_wait(&sem_forks[right]);   /* pick up right fork */

        long long eating_at = now_ns();
        pthread_mutex_lock(&stat_lock);
        total_wait_ns += (eating_at - hungry_at);
        pthread_mutex_unlock(&stat_lock);

        /* Eat */

        sem_post(&sem_forks[right]);
        sem_post(&sem_forks[left]);
        sem_post(&sem_room);
    }
    return NULL;
}

/* ═══════════════════════════════════════════════════════════════════════════
   SOLUTION 3: Monitor-based (Tanenbaum's state machine)
   State: THINKING / HUNGRY / EATING for each philosopher
   A philosopher eats only if both neighbours are not eating.
   ═══════════════════════════════════════════════════════════════════════════ */
PhilState        mon_state[MAX_PHIL];
pthread_mutex_t  mon_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t   mon_self[MAX_PHIL];

void mon_test(int i) {
    if (mon_state[i] == HUNGRY &&
        mon_state[(i + N_PHIL - 1) % N_PHIL] != EATING &&
        mon_state[(i + 1) % N_PHIL]           != EATING) {
        mon_state[i] = EATING;
        pthread_cond_signal(&mon_self[i]);
    }
}

void mon_pickup(int i) {
    pthread_mutex_lock(&mon_mutex);
    mon_state[i] = HUNGRY;
    mon_test(i);
    while (mon_state[i] != EATING)
        pthread_cond_wait(&mon_self[i], &mon_mutex);
    pthread_mutex_unlock(&mon_mutex);
}

void mon_putdown(int i) {
    pthread_mutex_lock(&mon_mutex);
    mon_state[i] = THINKING;
    mon_test((i + N_PHIL - 1) % N_PHIL);
    mon_test((i + 1) % N_PHIL);
    pthread_mutex_unlock(&mon_mutex);
}

void *mon_philosopher(void *arg) {
    int id = *(int *)arg;
    for (int m = 0; m < MEALS_PER_PHIL; m++) {
        long long hungry_at = now_ns();
        mon_pickup(id);
        long long eating_at = now_ns();

        pthread_mutex_lock(&stat_lock);
        total_wait_ns += (eating_at - hungry_at);
        pthread_mutex_unlock(&stat_lock);

        /* Eat */
        mon_putdown(id);
    }
    return NULL;
}

/* ── Run one configuration ─────────────────────────────────────────────── */
void run_solution(int solution, int N, int meals) {
    N_PHIL           = N;
    MEALS_PER_PHIL   = meals;
    total_wait_ns    = 0;
    deadlock_count   = 0;

    pthread_t threads[MAX_PHIL];
    int ids[MAX_PHIL];

    for (int i = 0; i < N; i++) ids[i] = i;

    /* Initialise synchronization primitives */
    if (solution == 1) {
        for (int i = 0; i < N; i++) pthread_mutex_init(&rh_forks[i], NULL);
    } else if (solution == 2) {
        sem_init(&sem_room, 0, N - 1);
        for (int i = 0; i < N; i++) sem_init(&sem_forks[i], 0, 1);
    } else {
        for (int i = 0; i < N; i++) {
            mon_state[i] = THINKING;
            pthread_cond_init(&mon_self[i], NULL);
        }
    }

    long long wall_start = now_ns();

    for (int i = 0; i < N; i++) {
        void *fn = (solution == 1) ? rh_philosopher
                 : (solution == 2) ? sem_philosopher
                 :                   mon_philosopher;
        pthread_create(&threads[i], NULL, fn, &ids[i]);
    }
    for (int i = 0; i < N; i++) pthread_join(threads[i], NULL);

    long long wall_end = now_ns();
    double wall_ms    = (wall_end - wall_start) / (double)NS_PER_MS;
    double avg_wait   = (N * meals > 0)
        ? (total_wait_ns / (double)(N * meals)) / NS_PER_MS : 0;
    double throughput = (N * meals) / (wall_ms / 1000.0);

    const char *sol_names[] = {"", "ResourceHierarchy", "Semaphore", "Monitor"};
    printf("solution=%s N=%d meals=%d wall=%.2f ms "
           "throughput=%.0f meals/s avg_wait=%.4f ms\n",
           sol_names[solution], N, meals, wall_ms, throughput, avg_wait);

    /* Cleanup */
    if (solution == 1) {
        for (int i = 0; i < N; i++) pthread_mutex_destroy(&rh_forks[i]);
    } else if (solution == 2) {
        sem_destroy(&sem_room);
        for (int i = 0; i < N; i++) sem_destroy(&sem_forks[i]);
    } else {
        for (int i = 0; i < N; i++) pthread_cond_destroy(&mon_self[i]);
    }
}

int main(int argc, char *argv[]) {
    int N       = (argc >= 2) ? atoi(argv[1]) : 5;
    int meals   = (argc >= 3) ? atoi(argv[2]) : 1000;
    int sol     = (argc >= 4) ? atoi(argv[3]) : 3;
    if (N > MAX_PHIL) { fprintf(stderr, "Max %d philosophers\n", MAX_PHIL); return 1; }
    run_solution(sol, N, meals);
    return 0;
}
