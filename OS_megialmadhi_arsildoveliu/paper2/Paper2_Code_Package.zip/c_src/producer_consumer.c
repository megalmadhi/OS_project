/*
 * producer_consumer.c
 * POSIX Pthreads implementation of the Bounded Buffer Producer-Consumer problem
 * Paper 2 — Multithreaded Synchronization & Performance
 * 
 * Synchronization: mutex + two condition variables (not_full, not_empty)
 * Supports: M producers, K consumers, buffer size N
 * 
 * Compile: gcc -O2 -pthread -o producer_consumer producer_consumer.c -lm
 * Usage:   ./producer_consumer <producers> <consumers> <buffer_size> <items_per_producer>
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* ── Configuration ─────────────────────────────────────────────────────── */
#define MAX_BUFFER   1024
#define MAX_THREADS  256
#define NS_PER_MS    1000000LL
#define NS_PER_S     1000000000LL

/* ── Shared bounded buffer ─────────────────────────────────────────────── */
typedef struct {
    int       data[MAX_BUFFER];
    int       head, tail, count;
    int       capacity;
    long long total_produced;
    long long total_consumed;
    long long total_wait_ns_prod;   /* cumulative producer wait time */
    long long total_wait_ns_cons;   /* cumulative consumer wait time */
    int       context_switches;
    pthread_mutex_t lock;
    pthread_cond_t  not_full;
    pthread_cond_t  not_empty;
} BoundedBuffer;

/* ── Thread arguments ──────────────────────────────────────────────────── */
typedef struct {
    BoundedBuffer *buf;
    int            id;
    int            items;          /* items to produce/consume */
    double         cpu_time_ms;    /* measured CPU time for this thread */
} ThreadArgs;

/* ── Statistics ────────────────────────────────────────────────────────── */
typedef struct {
    int    producers, consumers, buffer_size, items_total;
    double wall_time_ms;
    double throughput;             /* items/sec */
    double avg_latency_prod_ms;    /* avg producer wait per item */
    double avg_latency_cons_ms;    /* avg consumer wait per item */
    double cpu_usage_percent;
    int    context_switches;
    long   max_rss_kb;
} BenchResult;

/* ── Timer utility ─────────────────────────────────────────────────────── */
static long long now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * NS_PER_S + ts.tv_nsec;
}

/* ── Buffer operations ─────────────────────────────────────────────────── */
void buffer_init(BoundedBuffer *b, int capacity) {
    b->head = b->tail = b->count = 0;
    b->capacity = capacity;
    b->total_produced = b->total_consumed = 0;
    b->total_wait_ns_prod = b->total_wait_ns_cons = 0;
    b->context_switches = 0;
    pthread_mutex_init(&b->lock, NULL);
    pthread_cond_init(&b->not_full, NULL);
    pthread_cond_init(&b->not_empty, NULL);
}

void buffer_destroy(BoundedBuffer *b) {
    pthread_mutex_destroy(&b->lock);
    pthread_cond_destroy(&b->not_full);
    pthread_cond_destroy(&b->not_empty);
}

/* ── Producer thread ───────────────────────────────────────────────────── */
void *producer(void *arg) {
    ThreadArgs    *a = (ThreadArgs *)arg;
    BoundedBuffer *b = a->buf;
    struct timespec cpu_start, cpu_end;

    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &cpu_start);

    for (int i = 0; i < a->items; i++) {
        int value = a->id * 100000 + i;

        pthread_mutex_lock(&b->lock);

        long long wait_start = now_ns();
        while (b->count == b->capacity) {
            b->context_switches++;
            pthread_cond_wait(&b->not_full, &b->lock);
        }
        b->total_wait_ns_prod += (now_ns() - wait_start);

        /* Insert into buffer */
        b->data[b->tail] = value;
        b->tail = (b->tail + 1) % b->capacity;
        b->count++;
        b->total_produced++;

        pthread_cond_signal(&b->not_empty);
        pthread_mutex_unlock(&b->lock);
    }

    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &cpu_end);
    a->cpu_time_ms = ((cpu_end.tv_sec - cpu_start.tv_sec) * 1000.0)
                   + ((cpu_end.tv_nsec - cpu_start.tv_nsec) / 1e6);
    return NULL;
}

/* ── Consumer thread ───────────────────────────────────────────────────── */
void *consumer(void *arg) {
    ThreadArgs    *a = (ThreadArgs *)arg;
    BoundedBuffer *b = a->buf;
    struct timespec cpu_start, cpu_end;

    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &cpu_start);

    for (int i = 0; i < a->items; i++) {
        pthread_mutex_lock(&b->lock);

        long long wait_start = now_ns();
        while (b->count == 0) {
            b->context_switches++;
            pthread_cond_wait(&b->not_empty, &b->lock);
        }
        b->total_wait_ns_cons += (now_ns() - wait_start);

        /* Remove from buffer */
        int val = b->data[b->head];
        b->head = (b->head + 1) % b->capacity;
        b->count--;
        b->total_consumed++;

        pthread_cond_signal(&b->not_full);
        pthread_mutex_unlock(&b->lock);
        (void)val; /* suppress unused warning */
    }

    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &cpu_end);
    a->cpu_time_ms = ((cpu_end.tv_sec - cpu_start.tv_sec) * 1000.0)
                   + ((cpu_end.tv_nsec - cpu_start.tv_nsec) / 1e6);
    return NULL;
}

/* ── Run one benchmark configuration ──────────────────────────────────── */
BenchResult run_benchmark(int M, int K, int N, int items_per_producer) {
    BoundedBuffer buf;
    buffer_init(&buf, N);

    int total_items  = M * items_per_producer;
    int items_per_consumer = total_items / K;

    pthread_t    prod_threads[MAX_THREADS], cons_threads[MAX_THREADS];
    ThreadArgs   prod_args[MAX_THREADS],    cons_args[MAX_THREADS];

    /* Read /proc/self/status for memory before */
    long rss_before = 0;
    FILE *f = fopen("/proc/self/status", "r");
    if (f) {
        char line[128]; long v;
        while (fgets(line, sizeof(line), f))
            if (sscanf(line, "VmRSS: %ld", &v) == 1) { rss_before = v; break; }
        fclose(f);
    }

    long long wall_start = now_ns();

    /* Launch producers */
    for (int i = 0; i < M; i++) {
        prod_args[i] = (ThreadArgs){ .buf = &buf, .id = i, .items = items_per_producer };
        pthread_create(&prod_threads[i], NULL, producer, &prod_args[i]);
    }
    /* Launch consumers */
    for (int i = 0; i < K; i++) {
        cons_args[i] = (ThreadArgs){ .buf = &buf, .id = i, .items = items_per_consumer };
        pthread_create(&cons_threads[i], NULL, consumer, &cons_args[i]);
    }

    for (int i = 0; i < M; i++) pthread_join(prod_threads[i], NULL);
    for (int i = 0; i < K; i++) pthread_join(cons_threads[i], NULL);

    long long wall_end = now_ns();
    double wall_ms = (wall_end - wall_start) / (double)NS_PER_MS;

    /* Aggregate CPU time */
    double total_cpu_ms = 0;
    for (int i = 0; i < M; i++) total_cpu_ms += prod_args[i].cpu_time_ms;
    for (int i = 0; i < K; i++) total_cpu_ms += cons_args[i].cpu_time_ms;

    long rss_after = 0;
    f = fopen("/proc/self/status", "r");
    if (f) {
        char line[128]; long v;
        while (fgets(line, sizeof(line), f))
            if (sscanf(line, "VmRSS: %ld", &v) == 1) { rss_after = v; break; }
        fclose(f);
    }

    BenchResult r;
    r.producers        = M;
    r.consumers        = K;
    r.buffer_size      = N;
    r.items_total      = total_items;
    r.wall_time_ms     = wall_ms;
    r.throughput       = total_items / (wall_ms / 1000.0);
    r.avg_latency_prod_ms = buf.total_produced > 0
        ? (buf.total_wait_ns_prod / (double)buf.total_produced) / NS_PER_MS : 0;
    r.avg_latency_cons_ms = buf.total_consumed > 0
        ? (buf.total_wait_ns_cons / (double)buf.total_consumed) / NS_PER_MS : 0;
    r.cpu_usage_percent = wall_ms > 0 ? (total_cpu_ms / wall_ms) * 100.0 : 0;
    r.context_switches  = buf.context_switches;
    r.max_rss_kb        = rss_after - rss_before;

    buffer_destroy(&buf);
    return r;
}

/* ── Main ──────────────────────────────────────────────────────────────── */
int main(int argc, char *argv[]) {
    int M = 2, K = 2, N = 16, items = 50000;
    if (argc >= 2) M     = atoi(argv[1]);
    if (argc >= 3) K     = atoi(argv[2]);
    if (argc >= 4) N     = atoi(argv[3]);
    if (argc >= 5) items = atoi(argv[4]);

    if (M > MAX_THREADS || K > MAX_THREADS || N > MAX_BUFFER) {
        fprintf(stderr, "Error: limits exceeded (max threads=%d, max buffer=%d)\n",
                MAX_THREADS, MAX_BUFFER);
        return 1;
    }

    BenchResult r = run_benchmark(M, K, N, items);

    printf("M=%d K=%d N=%d items=%d "
           "wall=%.2f ms throughput=%.0f items/s "
           "lat_prod=%.3f ms lat_cons=%.3f ms "
           "cpu=%.1f%% ctx_sw=%d rss=%ld KB\n",
           r.producers, r.consumers, r.buffer_size, r.items_total,
           r.wall_time_ms, r.throughput,
           r.avg_latency_prod_ms, r.avg_latency_cons_ms,
           r.cpu_usage_percent, r.context_switches, r.max_rss_kb);

    return 0;
}
