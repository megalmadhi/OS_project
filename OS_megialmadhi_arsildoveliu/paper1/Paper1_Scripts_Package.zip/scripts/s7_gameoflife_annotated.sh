#!/bin/bash
# =============================================================================
# S7: life.sh — FULLY ANNOTATED VERSION (Game of Life)
# PURPOSE: Conway's Game of Life cellular automaton on a text grid
# USAGE:   ./s7_gameoflife_annotated.sh [gen0_file]
# RULES:   Live cell with 2-3 live neighbors → survives
#          Dead cell with exactly 3 live neighbors → born
#          All other cases → dead cell
# =============================================================================

SURVIVE=2
BIRTH=3
ALIVE1=.
DEAD1=_
ROWS=10
COLS=10
GENERATIONS=5    # Reduced for demo — increase for full run
NONE_ALIVE=85
DELAY=0          # Set to 0 for fast demo (original uses 2)
TRUE=0
FALSE=1
ALIVE=0
DEAD=1
startfile=${1:-gen0}

echo "=============================================="
echo "[INIT] Game of Life — Conway's Cellular Automaton"
echo "[INIT] Grid: ${ROWS}×${COLS} = $(( ROWS * COLS )) cells"
echo "[INIT] Generations to run: $GENERATIONS"
echo "[INIT] Start file: $startfile"
echo "[INIT] Rules: survive=$SURVIVE neighbors, birth=$BIRTH neighbors"
echo "=============================================="

# ── Check start file ──────────────────────────────────────────────────────
if [ ! -e "$startfile" ]; then
    echo "[PROBE 1] Start file '$startfile' not found. Creating default gen0..."
    cat > gen0 << 'GENEOF'
__.__..___
__.._.____
____.___..
_._______.
____._____
..__...___
____._____
___...____
__.._..___
_..___..__
GENEOF
    startfile=gen0
    echo "[PROBE 1] Created default gen0 (10×10 grid)"
fi

echo "[PROBE 1] Start file: $startfile"
echo "[PROBE 1] Grid content (. = alive, _ = dead):"
grep -v '^#' "$startfile" | sed 's/^/          /'

# ── Count initial live cells ──────────────────────────────────────────────
initial_alive=$(grep -v '^#' "$startfile" | grep -o '\.' | wc -l)
echo "[PROBE 2] Initial live cells: $initial_alive / $(( ROWS * COLS )) total"
echo "[PROBE 2] Initial occupancy: $(( initial_alive * 100 / (ROWS * COLS) ))%"

let "cells = $ROWS * $COLS"
declare -a initial
declare -a current

# ── Load initial generation ───────────────────────────────────────────────
echo "[PROBE 3] Loading initial array from file..."
initial=( $(cat "$startfile" | sed -e '/#/d' | tr -d '\n' | \
    sed -e 's/\./\. /g' -e 's/_/_ /g') )
echo "[PROBE 3] Array loaded: ${#initial[@]} elements"
echo "[PROBE 3] Sample elements [0-4]: ${initial[0]} ${initial[1]} ${initial[2]} ${initial[3]} ${initial[4]}"

avar=
generation=0

# ── Display function ───────────────────────────────────────────────────────
display() {
    alive=0
    declare -a arr
    arr=( $(echo "$1") )
    for ((i=0; i<${#arr[@]}; i++)); do
        let "rowcheck = $i % COLS"
        [ "$rowcheck" -eq 0 ] && { echo; echo -n "  "; }
        cell=${arr[i]}
        [ "$cell" = "." ] && let "alive += 1"
        echo -n "$cell" | sed -e 's/_/ /g'
    done
    return
}

# ── IsValid boundary check ─────────────────────────────────────────────────
IsValid() {
    [ -z "$1" -o -z "$2" ] && return $FALSE
    local lower_limit=0
    let "upper_limit = $ROWS * $COLS - 1"
    [ "$1" -lt "$lower_limit" -o "$1" -gt "$upper_limit" ] && return $FALSE
    local row=$2
    let "left = $row * $COLS"
    let "right = $left + $COLS - 1"
    [ "$1" -lt "$left" -o "$1" -gt "$right" ] && return $FALSE
    return $TRUE
}

# ── GetCount: count live neighbors ────────────────────────────────────────
GetCount() {
    local cell_number=$2
    local array
    local count=0
    local ROW_NHBD=3
    array=( $(echo "$1") )
    let "top = $cell_number - $COLS - 1"
    let "center = $cell_number - 1"
    let "bottom = $cell_number + $COLS - 1"
    let "r = $cell_number / $COLS"
    for ((i=0; i<$ROW_NHBD; i++)); do
        let "t_top = $top + $i"
        let "t_cen = $center + $i"
        let "t_bot = $bottom + $i"
        IsValid $t_cen $r && [ "${array[$t_cen]}" = "$ALIVE1" ] && let "count += 1"
        let "row_up = $r - 1"
        IsValid $t_top $row_up && [ "${array[$t_top]}" = "$ALIVE1" ] && let "count += 1"
        let "row_dn = $r + 1"
        IsValid $t_bot $row_dn && [ "${array[$t_bot]}" = "$ALIVE1" ] && let "count += 1"
    done
    [ "${array[$cell_number]}" = "$ALIVE1" ] && let "count -= 1"
    return $count
}

# ── IsAlive: apply Game of Life rules ─────────────────────────────────────
IsAlive() {
    GetCount "$1" $2
    local nhbd=$?
    [ "$nhbd" -eq "$BIRTH" ] && return $ALIVE
    [ "$3" = "." -a "$nhbd" -eq "$SURVIVE" ] && return $ALIVE
    return $DEAD
}

# ── next_gen: compute next generation ─────────────────────────────────────
next_gen() {
    local array
    local i=0
    array=( $(echo "$1") )
    while [ "$i" -lt "$cells" ]; do
        IsAlive "$1" $i ${array[$i]}
        [ $? -eq "$ALIVE" ] && array[$i]=. || array[$i]="_"
        let "i += 1"
    done
    avar=$(echo ${array[@]})
    display "$avar"
    echo; echo
    echo "  Generation $generation — $alive alive cells"
    [ "$alive" -eq 0 ] && { echo "[PROBE] All cells dead — premature exit"; exit $NONE_ALIVE; }
}

# ── Run simulation ────────────────────────────────────────────────────────
echo ""
echo "=============================================="
echo "  SIMULATION START"
echo "=============================================="

Gen0=$(echo ${initial[@]})
echo ""
echo "  GENERATION 0 (initial state):"
display "$Gen0"
echo; echo
echo "  Generation 0 — $alive alive cells"
echo "[PROBE 4] Gen 0: $alive alive cells out of $cells total"

sleep $DELAY
let "generation += 1"
Cur=$(echo ${initial[@]})
echo "  GENERATION 1:"
next_gen "$Cur"
echo "[PROBE 5] Gen 1 computed: $alive alive cells"
sleep $DELAY
let "generation += 1"

while [ "$generation" -le "$GENERATIONS" ]; do
    Cur="$avar"
    echo "  GENERATION $generation:"
    next_gen "$Cur"
    echo "[PROBE 6] Gen $generation: $alive alive cells"
    let "generation += 1"
    sleep $DELAY
done

echo ""
echo "=============================================="
echo "[DONE] Simulation complete"
echo "[DONE] Final generation: $generation"
echo "[DONE] Final alive cells: $alive"
echo "=============================================="
echo ""
echo "COMPLEXITY NOTE:"
echo "  Per generation: O(ROWS × COLS × 9) = O($(( ROWS * COLS * 9 ))) operations"
echo "  Total: O($GENERATIONS × ROWS × COLS × 9) = O($(( GENERATIONS * ROWS * COLS * 9 )))"
echo "  Pure Bash implementation — consider awk/Python for grids > 30×30"
exit 0
