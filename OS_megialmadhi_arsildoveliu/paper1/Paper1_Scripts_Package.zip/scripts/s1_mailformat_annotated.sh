#!/bin/bash
# =============================================================================
# S1: mail-format.sh  — FULLY ANNOTATED VERSION
# Paper 1: Experimental Analysis of Unix Shell Scripts
# =============================================================================
# PURPOSE: Formats e-mail messages by removing quoting carets/tabs
#          and folding excessively long lines to MAXWIDTH characters.
# USAGE:   ./s1_mailformat_annotated.sh <email_file>
# =============================================================================

ARGS=1
E_BADARGS=85
E_NOFILE=86

echo "=============================================="
echo "[INIT] Script: $(basename $0)"
echo "[INIT] PID: $$"
echo "[INIT] Bash version: $BASH_VERSION"
echo "[INIT] Running as user: $(whoami)"
echo "[INIT] Arguments received: $#"
echo "[INIT] Argument value: '$1'"
echo "=============================================="

# ── Argument validation ───────────────────────────────────────────────────
if [ $# -ne $ARGS ]; then
    echo "[ERROR] Wrong number of arguments. Expected $ARGS, got $#"
    echo "Usage: $(basename $0) filename"
    exit $E_BADARGS
fi
echo "[PROBE 1] Argument count check PASSED: $# argument(s)"

# ── File existence check ──────────────────────────────────────────────────
if [ -f "$1" ]; then
    file_name=$1
    echo "[PROBE 2] File existence check PASSED: '$file_name' exists"
    echo "[PROBE 2] File size: $(wc -c < "$file_name") bytes"
    echo "[PROBE 2] Line count: $(wc -l < "$file_name") lines"
else
    echo "[ERROR] File '$1' does not exist."
    exit $E_NOFILE
fi

# ── Configuration ─────────────────────────────────────────────────────────
MAXWIDTH=70
echo "[PROBE 3] MAXWIDTH set to: $MAXWIDTH"

# ── Build sed script ──────────────────────────────────────────────────────
# This sed script stored in a variable is applied in one pass:
#   s/^>//         removes leading single caret
#   s/^ *>//       removes leading spaces followed by caret
#   s/^ *//        removes any remaining leading spaces
#   s/ *//         removes multiple consecutive spaces (first occurrence)
sedscript='s/^>//
s/^ *>//
s/^ *//
s/ *//'
echo "[PROBE 4] sed script defined:"
echo "$sedscript" | sed 's/^/          /'

# ── Show first 3 lines of input (intermediate result) ────────────────────
echo "[PROBE 5] First 3 lines of INPUT file:"
head -3 "$file_name" | cat -A | sed 's/^/          /'

# ── Apply transformation ──────────────────────────────────────────────────
echo "[PROBE 6] Applying sed transformation then fold..."
echo "          Pipeline: sed | fold -s --width=$MAXWIDTH"
echo "---------- PROCESSED OUTPUT START ----------"
sed "$sedscript" "$file_name" | fold -s --width=$MAXWIDTH
echo "---------- PROCESSED OUTPUT END ------------"

EXIT_CODE=$?
echo "[PROBE 7] Pipeline exit code: $EXIT_CODE"
echo "[DONE] Processing complete."
exit $EXIT_CODE
