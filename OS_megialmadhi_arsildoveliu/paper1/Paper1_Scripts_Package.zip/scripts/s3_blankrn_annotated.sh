#!/bin/bash
# =============================================================================
# S3: blank-rename.sh — FULLY ANNOTATED VERSION
# PURPOSE: Replace spaces with underscores in all filenames in current dir
# =============================================================================
ONE=1; number=0; FOUND=0

echo "=============================================="
echo "[INIT] blank-rename.sh"
echo "[INIT] Working directory: $(pwd)"
echo "[INIT] Total files in directory: $(ls | wc -l)"
echo "=============================================="

echo "[PROBE 1] Starting scan for filenames with spaces..."
space_count=0

for filename in *; do
    echo "[PROBE 2] Testing: '$filename'"
    echo "$filename" | grep -q " "
    if [ $? -eq $FOUND ]; then
        space_count=$((space_count + 1))
        fname=$filename
        echo "[PROBE 3]   CONTAINS SPACE(S) — will rename"
        n=$(echo "$fname" | sed -e 's/ /_/g')
        echo "[PROBE 4]   Original: '$fname'"
        echo "[PROBE 4]   New name: '$n'"
        mv "$fname" "$n"
        echo "[PROBE 5]   mv exit code: $?"
        let "number += 1"
    else
        echo "[PROBE 2]   No spaces, skipping"
    fi
done

echo "[PROBE 6] Files with spaces found: $space_count"
echo "[PROBE 7] Files successfully renamed: $number"
[ "$number" -eq "$ONE" ] && echo "$number file renamed." || echo "$number files renamed."
exit 0
