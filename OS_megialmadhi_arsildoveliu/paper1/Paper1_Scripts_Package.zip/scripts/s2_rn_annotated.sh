#!/bin/bash
# =============================================================================
# S2: rn.sh  — FULLY ANNOTATED VERSION
# PURPOSE: Pattern-based file renaming utility
# USAGE:   ./s2_rn_annotated.sh old-pattern new-pattern
# =============================================================================
ARGS=2; E_BADARGS=85; ONE=1

echo "=============================================="
echo "[INIT] rn.sh - File Renaming Utility"
echo "[INIT] Working directory: $(pwd)"
echo "[INIT] Arguments: '$1' -> '$2'"
echo "=============================================="

if [ $# -ne "$ARGS" ]; then
    echo "[ERROR] Expected 2 arguments, got $#"
    echo "Usage: $(basename $0) old-pattern new-pattern"
    exit $E_BADARGS
fi
echo "[PROBE 1] Arguments validated: old='$1' new='$2'"

number=0
echo "[PROBE 2] Scanning for files matching: *$1*"
file_list=( *"$1"* )
echo "[PROBE 2] Potential matches found: ${#file_list[@]}"

for filename in *"$1"*; do
    echo "[PROBE 3] Testing: '$filename'"
    if [ -f "$filename" ]; then
        fname=$(basename "$filename")
        echo "[PROBE 4]   Is regular file: YES"
        echo "[PROBE 4]   basename: '$fname'"
        n=$(echo "$fname" | sed -e "s/$1/$2/")
        echo "[PROBE 5]   New name: '$n'"
        if [ "$fname" != "$n" ]; then
            mv "$fname" "$n"
            echo "[PROBE 6]   Renamed successfully"
            let "number += 1"
        else
            echo "[PROBE 6]   Skipped (names identical)"
        fi
    else
        echo "[PROBE 3]   Not a regular file, skipping"
    fi
done

echo "[PROBE 7] Total files renamed: $number"
if [ "$number" -eq "$ONE" ]; then
    echo "$number file renamed."
else
    echo "$number files renamed."
fi
exit $?
