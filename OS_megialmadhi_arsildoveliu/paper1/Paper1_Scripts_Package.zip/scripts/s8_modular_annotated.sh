#!/bin/bash
# =============================================================================
# S8: modular-arithmetic.sh — FULLY ANNOTATED VERSION
# PURPOSE: Find smallest n satisfying: n≡3(mod5), n≡4(mod7), n≡5(mod9)
# =============================================================================
MAX=10000
echo "=============================================="
echo "[INIT] Modular Arithmetic — Brute Force Search"
echo "[INIT] Searching for n in [1, $MAX)"
echo "[INIT] Constraints: n%5=3, n%7=4, n%9=5"
echo "[INIT] LCM(5,7,9) = 315, so solution repeats every 315"
echo "=============================================="

passed_mod5=0; passed_mod7=0; iteration_count=0

for ((nr=1; nr<$MAX; nr++)); do
    (( iteration_count++ ))

    # Show detail for first 20 and around solution
    if [ $nr -le 5 ] || [ $nr -eq 158 ] || [ $((nr % 315)) -eq 157 ]; then
        echo "[PROBE 1] Testing nr=$nr"
    fi

    let "t1 = nr % 5"
    if [ "$t1" -ne 3 ]; then
        [ $nr -le 3 ] && echo "[PROBE 2]   nr%5=$t1 ≠ 3 → SKIP (mod5 fail)"
        continue
    fi
    (( passed_mod5++ ))
    [ $nr -le 20 ] && echo "[PROBE 2]   nr%5=$t1 == 3 ✓ (passed mod5, total passed: $passed_mod5)"

    let "t2 = nr % 7"
    if [ "$t2" -ne 4 ]; then
        [ $nr -le 20 ] && echo "[PROBE 3]   nr%7=$t2 ≠ 4 → SKIP (mod7 fail)"
        continue
    fi
    (( passed_mod7++ ))
    echo "[PROBE 3]   nr%7=$t2 == 4 ✓ (passed mod7, total passed: $passed_mod7)"

    let "t3 = nr % 9"
    if [ "$t3" -ne 5 ]; then
        echo "[PROBE 4]   nr%9=$t3 ≠ 5 → SKIP (mod9 fail)"
        continue
    fi

    echo "[PROBE 5]   nr%9=$t3 == 5 ✓ — ALL THREE CONSTRAINTS SATISFIED!"
    echo "[PROBE 6]   Solution found after $iteration_count iterations"
    break
done

echo ""
echo "=============================================="
echo "RESULT: Number = $nr"
echo "Verification: $nr%5=$(( nr%5 )), $nr%7=$(( nr%7 )), $nr%9=$(( nr%9 ))"
echo "Iterations needed (brute force): $iteration_count"
echo "=============================================="
exit 0
