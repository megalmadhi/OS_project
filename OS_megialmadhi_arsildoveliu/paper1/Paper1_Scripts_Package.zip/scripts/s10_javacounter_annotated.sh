#!/bin/bash
# =============================================================================
# S10: java-line-counter.sh — FULLY ANNOTATED VERSION
# PURPOSE: Count total lines across all .java files under src/
# Original one-liner: export SUM=0; for f in $(find src -name "*.java");
#   do export SUM=$(($SUM + $(wc -l $f | awk '{print $1}'))); done; echo $SUM
# =============================================================================

SRC_DIR=${1:-./src}

echo "=============================================="
echo "[INIT] Java Line Counter"
echo "[INIT] Source directory: $SRC_DIR"
echo "[INIT] This script demonstrates O(N) fork problem"
echo "=============================================="

if [ ! -d "$SRC_DIR" ]; then
    echo "[INFO] Directory '$SRC_DIR' not found."
    echo "[INFO] Creating demo structure for illustration..."
    mkdir -p "$SRC_DIR"
    for i in 1 2 3; do
        printf "// Demo Java file $i\npublic class Demo$i {\n    public static void main(String[] a) {}\n}\n" > "$SRC_DIR/Demo$i.java"
    done
fi

echo "[PROBE 1] Finding all .java files..."
java_files=( $(find "$SRC_DIR" -name "*.java") )
file_count=${#java_files[@]}
echo "[PROBE 1] Found $file_count .java file(s)"

echo ""
echo "[PROBE 2] ORIGINAL METHOD — O(N) forks:"
echo "          Each file: 1 wc fork + 1 awk fork = 2N total forks"
echo "          For N=$file_count files = $((file_count * 2)) child processes"
echo ""

export SUM=0
for f in "${java_files[@]}"; do
    lines=$(wc -l "$f" | awk '{print $1}')
    echo "[PROBE 3]   File: $f  Lines: $lines  Running total: $((SUM + lines))"
    export SUM=$(( SUM + lines ))
done
echo ""
echo "[PROBE 4] ORIGINAL result: $SUM total lines (used $((file_count * 2)) forks)"

echo ""
echo "[PROBE 5] OPTIMIZED METHOD — O(1) forks:"
echo "          Single pipeline: find | xargs | wc | awk"
echo "          Always 4 processes regardless of file count"
echo ""
OPT_TOTAL=$(find "$SRC_DIR" -name "*.java" -print0 | xargs -0 wc -l 2>/dev/null | tail -1 | awk '{print $1}')
echo "[PROBE 6] OPTIMIZED result: $OPT_TOTAL total lines (used 4 forks)"

echo ""
echo "=============================================="
echo "RESULT: $SUM lines across $file_count Java file(s)"
echo "Original forks: $((file_count * 2))  |  Optimized forks: 4"
echo "=============================================="
exit 0
