#!/bin/bash
# =============================================================================
# S4: encryptedpw.sh — FULLY ANNOTATED VERSION
# PURPOSE: Upload a file to FTP using a locally encrypted password
# USAGE:   ./s4_encryptedpw_annotated.sh <filename>
# NOTE:    Requires 'cruft' encryption tool and valid server config
#          This script is analyzed for security vulnerabilities — see probes
# =============================================================================

E_BADARGS=85

echo "=============================================="
echo "[INIT] encryptedpw.sh — Secure FTP Uploader"
echo "[INIT] PID: $$"
echo "[INIT] Arguments: $#  →  '$1'"
echo "=============================================="

# ── Argument validation ───────────────────────────────────────────────────
if [ -z "$1" ]; then
    echo "[ERROR] No filename argument provided."
    echo "Usage: $(basename $0) filename"
    exit $E_BADARGS
fi
echo "[PROBE 1] Argument check PASSED: file='$1'"

# ── Configuration (would be set to real values in production) ─────────────
Username=bozo
pword=/home/bozo/secret/password_encrypted.file
Filename=$(basename "$1")
Server="ftp.example.com"
Directory="/uploads"

echo "[PROBE 2] Configuration loaded:"
echo "          Username: $Username"
echo "          Encrypted password file: $pword"
echo "          Upload filename: $Filename"
echo "          Server: $Server"
echo "          Directory: $Directory"

# ── Security Analysis (PROBE shows vulnerability) ────────────────────────
echo "[PROBE 3] SECURITY ANALYSIS:"
echo "          ⚠ Password will be decrypted into shell variable"
echo "          ⚠ FTP transmits credentials in CLEARTEXT over network"
echo "          ⚠ Decrypted password visible in /proc/$$/environ briefly"
echo "          ✓ Encrypted password file protects at-rest storage"
echo "          RECOMMENDATION: Use SFTP/SCP with key-based auth instead"

# ── Check if password file exists ─────────────────────────────────────────
echo "[PROBE 4] Checking encrypted password file..."
if [ -f "$pword" ]; then
    echo "          Password file found: $pword"
    echo "          File permissions: $(stat -c '%a %U' $pword 2>/dev/null || echo 'N/A')"
else
    echo "          Password file NOT found (expected at $pword)"
    echo "          [SIMULATION MODE] Demonstrating script logic only"
fi

# ── Password decryption step ──────────────────────────────────────────────
echo "[PROBE 5] Decryption step:"
echo "          Command: Password=\$(cruft <\$pword)"
echo "          cruft uses one-time pad algorithm for decryption"
echo "          [SIMULATED — cruft not installed]"
# In production: Password=`cruft <$pword`
Password="[SIMULATED_DECRYPTED_PASSWORD]"
echo "          Decrypted password loaded into memory (length: ${#Password} chars)"

# ── FTP session via here-document ────────────────────────────────────────
echo "[PROBE 6] FTP session would execute:"
echo "          ftp -n \$Server <<End-Of-Session"
echo "            user \$Username \$Password"
echo "            binary"
echo "            bell"
echo "            cd \$Directory"
echo "            put \$Filename"
echo "            bye"
echo "          End-Of-Session"
echo ""
echo "          -n flag: disable auto-login (manual login via here-doc)"
echo "          binary:  set binary transfer mode"
echo "          bell:    ring bell on completion"
echo "          put:     upload the file"

# ── Optimized version hint ────────────────────────────────────────────────
echo ""
echo "[PROBE 7] OPTIMIZED VERSION (uses SFTP with key auth):"
echo "          TMPBATCH=\$(mktemp); chmod 600 \"\$TMPBATCH\""
echo "          trap 'rm -f \"\$TMPBATCH\"' EXIT"
echo "          printf 'put %s\\nbye\\n' \"\$Filename\" > \"\$TMPBATCH\""
echo "          sftp -b \"\$TMPBATCH\" \"\${Username}@\${Server}:\${Directory}\""
echo "          Benefit: no password in memory, encrypted transport, key auth"

echo ""
echo "=============================================="
echo "[DONE] Script analysis complete (simulation mode)"
echo "=============================================="
exit 0
