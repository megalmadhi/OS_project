#!/bin/bash
# S3 OPTIMIZED — built-in glob + parameter expansion, zero extra forks
number=0
for filename in *; do
    [[ "$filename" == *' '* ]] || continue   # Built-in test, no grep fork
    n="${filename// /_}"                      # Built-in substitution, no sed fork
    mv -- "$filename" "$n" && (( number++ ))
done
[ "$number" -eq 1 ] && echo "$number file renamed." || echo "$number files renamed."
