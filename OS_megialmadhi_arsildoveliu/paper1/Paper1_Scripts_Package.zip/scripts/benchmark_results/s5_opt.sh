#!/bin/bash
MAX_ITERATIONS=200; h=27
for ((i=1; i<=MAX_ITERATIONS; i++)); do
    printf "%7d" $h
    if (( h & 1 )); then (( h = h*3 + 1 )); else (( h /= 2 )); fi
    (( i % 10 == 0 )) && echo
done; echo
