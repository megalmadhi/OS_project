#!/bin/bash
for ((nr=1; nr<10000; nr++)); do
    let "t1 = nr % 5"; [ "$t1" -ne 3 ] && continue
    let "t2 = nr % 7"; [ "$t2" -ne 4 ] && continue
    let "t3 = nr % 9"; [ "$t3" -ne 5 ] && continue
    break
done; echo "n=$nr"
