#!/bin/bash
sedscript='s/^>//
s/^ *>//
s/^ *//
s/ *//'
sed "$sedscript" "$1" | fold -s --width=70
