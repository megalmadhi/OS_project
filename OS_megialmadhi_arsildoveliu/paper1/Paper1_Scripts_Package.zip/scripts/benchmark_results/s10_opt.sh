#!/bin/bash
total=$(find ./src -name "*.java" -print0 | xargs -0 wc -l 2>/dev/null | tail -1 | awk '{print $1}')
echo "Total: $total lines"
