#!/bin/bash
MAX_ITERATIONS=200; h=27
for ((i=1; i<=MAX_ITERATIONS; i++)); do
    printf "%7d" $h
    let "remainder = h % 2"
    if [ "$remainder" -eq 0 ]; then let "h /= 2"; else let "h = h*3 + 1"; fi
    let "line_break = i % 10"; [ "$line_break" -eq 0 ] && echo
done; echo
