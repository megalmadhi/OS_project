// Java file 28
public class File28 {
    public static void main(String[] a) {}
    // method body
}
