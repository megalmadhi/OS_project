// Java file 18
public class File18 {
    public static void main(String[] a) {}
    // method body
}
