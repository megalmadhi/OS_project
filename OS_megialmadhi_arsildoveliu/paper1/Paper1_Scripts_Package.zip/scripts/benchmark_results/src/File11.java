// Java file 11
public class File11 {
    public static void main(String[] a) {}
    // method body
}
