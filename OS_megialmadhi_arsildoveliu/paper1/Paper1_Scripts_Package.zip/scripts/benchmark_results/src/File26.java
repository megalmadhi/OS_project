// Java file 26
public class File26 {
    public static void main(String[] a) {}
    // method body
}
