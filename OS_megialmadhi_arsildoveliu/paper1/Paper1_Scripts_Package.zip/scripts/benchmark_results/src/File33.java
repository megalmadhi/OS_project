// Java file 33
public class File33 {
    public static void main(String[] a) {}
    // method body
}
