// Java file 3
public class File3 {
    public static void main(String[] a) {}
    // method body
}
