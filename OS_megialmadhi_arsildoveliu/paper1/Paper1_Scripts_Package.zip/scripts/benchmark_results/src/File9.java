// Java file 9
public class File9 {
    public static void main(String[] a) {}
    // method body
}
