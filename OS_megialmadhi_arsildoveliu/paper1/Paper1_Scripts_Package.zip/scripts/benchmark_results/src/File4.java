// Java file 4
public class File4 {
    public static void main(String[] a) {}
    // method body
}
