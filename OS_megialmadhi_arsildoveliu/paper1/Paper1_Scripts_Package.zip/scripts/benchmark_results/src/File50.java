// Java file 50
public class File50 {
    public static void main(String[] a) {}
    // method body
}
