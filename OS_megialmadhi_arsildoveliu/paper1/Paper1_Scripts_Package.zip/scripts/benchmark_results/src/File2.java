// Java file 2
public class File2 {
    public static void main(String[] a) {}
    // method body
}
