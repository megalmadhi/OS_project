// Java file 36
public class File36 {
    public static void main(String[] a) {}
    // method body
}
