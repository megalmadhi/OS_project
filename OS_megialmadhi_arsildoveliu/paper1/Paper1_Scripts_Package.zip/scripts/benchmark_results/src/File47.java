// Java file 47
public class File47 {
    public static void main(String[] a) {}
    // method body
}
