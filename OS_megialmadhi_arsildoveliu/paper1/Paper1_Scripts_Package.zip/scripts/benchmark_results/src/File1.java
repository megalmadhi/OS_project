// Java file 1
public class File1 {
    public static void main(String[] a) {}
    // method body
}
