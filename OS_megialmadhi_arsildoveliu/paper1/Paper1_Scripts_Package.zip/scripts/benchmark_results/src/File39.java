// Java file 39
public class File39 {
    public static void main(String[] a) {}
    // method body
}
