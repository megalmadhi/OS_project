// Java file 14
public class File14 {
    public static void main(String[] a) {}
    // method body
}
