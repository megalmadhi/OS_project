// Java file 5
public class File5 {
    public static void main(String[] a) {}
    // method body
}
