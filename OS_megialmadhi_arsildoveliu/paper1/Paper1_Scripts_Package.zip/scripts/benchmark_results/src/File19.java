// Java file 19
public class File19 {
    public static void main(String[] a) {}
    // method body
}
