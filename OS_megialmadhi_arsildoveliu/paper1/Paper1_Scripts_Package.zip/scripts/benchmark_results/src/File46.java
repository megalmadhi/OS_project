// Java file 46
public class File46 {
    public static void main(String[] a) {}
    // method body
}
