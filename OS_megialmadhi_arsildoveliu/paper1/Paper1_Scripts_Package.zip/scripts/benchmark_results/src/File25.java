// Java file 25
public class File25 {
    public static void main(String[] a) {}
    // method body
}
