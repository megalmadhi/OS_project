// Java file 31
public class File31 {
    public static void main(String[] a) {}
    // method body
}
