// Java file 12
public class File12 {
    public static void main(String[] a) {}
    // method body
}
