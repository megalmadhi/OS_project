// Java file 17
public class File17 {
    public static void main(String[] a) {}
    // method body
}
