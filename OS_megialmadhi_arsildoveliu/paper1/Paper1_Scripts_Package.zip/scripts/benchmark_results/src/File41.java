// Java file 41
public class File41 {
    public static void main(String[] a) {}
    // method body
}
