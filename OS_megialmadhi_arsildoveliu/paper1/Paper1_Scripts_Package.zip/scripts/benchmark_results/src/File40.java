// Java file 40
public class File40 {
    public static void main(String[] a) {}
    // method body
}
