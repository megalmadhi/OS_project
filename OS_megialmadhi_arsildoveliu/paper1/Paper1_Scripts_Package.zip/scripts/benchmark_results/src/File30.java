// Java file 30
public class File30 {
    public static void main(String[] a) {}
    // method body
}
