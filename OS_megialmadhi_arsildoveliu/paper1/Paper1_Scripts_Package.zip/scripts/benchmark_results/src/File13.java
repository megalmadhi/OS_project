// Java file 13
public class File13 {
    public static void main(String[] a) {}
    // method body
}
