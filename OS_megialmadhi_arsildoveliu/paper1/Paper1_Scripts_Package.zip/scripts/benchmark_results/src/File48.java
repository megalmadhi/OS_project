// Java file 48
public class File48 {
    public static void main(String[] a) {}
    // method body
}
