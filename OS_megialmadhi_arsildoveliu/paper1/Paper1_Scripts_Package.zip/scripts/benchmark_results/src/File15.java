// Java file 15
public class File15 {
    public static void main(String[] a) {}
    // method body
}
