// Java file 49
public class File49 {
    public static void main(String[] a) {}
    // method body
}
