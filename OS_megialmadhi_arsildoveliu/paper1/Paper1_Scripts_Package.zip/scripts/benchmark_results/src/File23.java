// Java file 23
public class File23 {
    public static void main(String[] a) {}
    // method body
}
