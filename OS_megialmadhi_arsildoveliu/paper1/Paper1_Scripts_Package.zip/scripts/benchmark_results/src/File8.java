// Java file 8
public class File8 {
    public static void main(String[] a) {}
    // method body
}
