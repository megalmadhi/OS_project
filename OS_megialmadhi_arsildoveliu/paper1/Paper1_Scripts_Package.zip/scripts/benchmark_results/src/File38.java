// Java file 38
public class File38 {
    public static void main(String[] a) {}
    // method body
}
