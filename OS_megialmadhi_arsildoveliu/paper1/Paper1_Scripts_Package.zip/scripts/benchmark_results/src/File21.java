// Java file 21
public class File21 {
    public static void main(String[] a) {}
    // method body
}
