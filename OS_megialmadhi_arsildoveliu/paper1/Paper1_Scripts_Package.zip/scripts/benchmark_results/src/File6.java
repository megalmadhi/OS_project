// Java file 6
public class File6 {
    public static void main(String[] a) {}
    // method body
}
