// Java file 22
public class File22 {
    public static void main(String[] a) {}
    // method body
}
