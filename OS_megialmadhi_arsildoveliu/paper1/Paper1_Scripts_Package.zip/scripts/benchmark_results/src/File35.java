// Java file 35
public class File35 {
    public static void main(String[] a) {}
    // method body
}
