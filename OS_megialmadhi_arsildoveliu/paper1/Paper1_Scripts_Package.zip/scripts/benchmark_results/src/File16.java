// Java file 16
public class File16 {
    public static void main(String[] a) {}
    // method body
}
