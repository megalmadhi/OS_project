// Java file 7
public class File7 {
    public static void main(String[] a) {}
    // method body
}
