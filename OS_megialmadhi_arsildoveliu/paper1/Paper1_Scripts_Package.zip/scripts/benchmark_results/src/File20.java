// Java file 20
public class File20 {
    public static void main(String[] a) {}
    // method body
}
