// Java file 10
public class File10 {
    public static void main(String[] a) {}
    // method body
}
