#!/bin/bash
export SUM=0
for f in $(find ./src -name "*.java"); do
    export SUM=$(($SUM + $(wc -l $f | awk '{print $1}')))
done; echo "Total: $SUM lines"
