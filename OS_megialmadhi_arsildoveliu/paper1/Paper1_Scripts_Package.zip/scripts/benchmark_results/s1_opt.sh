#!/bin/bash
awk -v maxw=70 '{
    gsub(/^[> ]+/, ""); gsub(/  +/, " ")
    while (length($0) > maxw) {
        i = maxw
        while (i > 0 && substr($0,i,1) != " ") i--
        if (i == 0) i = maxw
        print substr($0, 1, i); $0 = substr($0, i+1)
    }; print
}' "$1"
