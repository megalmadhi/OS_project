#!/bin/bash
# =============================================================================
# S6: days-between.sh — FULLY ANNOTATED VERSION
# PURPOSE: Calculate days between two dates using Gauss's Formula
# USAGE:   ./s6_daysbetween_annotated.sh MM/DD/YYYY MM/DD/YYYY
# =============================================================================

ARGS=2; E_PARAM_ERR=85; REFYR=1600; CENTURY=100
DIY=365; ADJ_DIY=367; MIY=12; DIM=31; LEAPCYCLE=4; MAXRETVAL=255
diff=; value=; day=; month=; year=

echo "=============================================="
echo "[INIT] days-between.sh — Date Difference Calculator"
echo "[INIT] Arguments: '$1'  '$2'"
echo "[INIT] Reference year: $REFYR (Gauss Formula base)"
echo "=============================================="

Param_Error() {
    echo "[ERROR] Invalid parameters."
    echo "Usage: $(basename $0) [M]M/[D]D/YYYY [M]M/[D]D/YYYY"
    echo "       (dates must be after 1/3/1600)"
    exit $E_PARAM_ERR
}

Parse_Date() {
    echo "[PROBE 1] Parsing date: '$1'"
    month=${1%%/**}
    dm=${1%/**}
    day=${dm#*/}
    let "year = $(basename $1)"
    echo "[PROBE 1]   → month=$month, day=$day, year=$year"
}

check_date() {
    echo "[PROBE 2] Validating: day=$1, month=$2, year=$3"
    [ "$1" -gt "$DIM" ] || [ "$2" -gt "$MIY" ] || [ "$3" -lt "$REFYR" ] && Param_Error
    echo "[PROBE 2]   Validation PASSED"
}

strip_leading_zero() {
    echo "[PROBE 3] Stripping leading zero from: '$1'"
    return ${1#0}
}

day_index() {
    echo "[PROBE 4] Computing day_index for: day=$1 month=$2 year=$3"
    local day=$1; local month=$2; local year=$3
    let "month = $month - 2"
    if [ "$month" -le 0 ]; then
        let "month += 12"; let "year -= 1"
        echo "[PROBE 4]   Jan/Feb adjustment: month=$month year=$year"
    fi
    let "year -= $REFYR"
    let "indexyr = $year / $CENTURY"
    let "Days = $DIY*$year + $year/$LEAPCYCLE - $indexyr + $indexyr/$LEAPCYCLE + $ADJ_DIY*$month/$MIY + $day - $DIM"
    echo "[PROBE 4]   Gauss result: Days=$Days"
    echo $Days
}

calculate_difference() {
    let "diff = $1 - $2"
    echo "[PROBE 5] date1_index=$1, date2_index=$2, diff=$diff"
}

abs() {
    if [ "$1" -lt 0 ]; then let "value = 0 - $1"
    else let "value = $1"; fi
    echo "[PROBE 6] abs($1) = $value"
}

if [ $# -ne "$ARGS" ]; then Param_Error; fi

echo ""
echo "[STEP 1] Processing first date: $1"
Parse_Date $1
check_date $day $month $year
strip_leading_zero $day; day=$?
strip_leading_zero $month; month=$?
let "date1 = $(day_index $day $month $year)"
echo "[STEP 1] date1_index = $date1"

echo ""
echo "[STEP 2] Processing second date: $2"
Parse_Date $2
check_date $day $month $year
strip_leading_zero $day; day=$?
strip_leading_zero $month; month=$?
date2=$(day_index $day $month $year)
echo "[STEP 2] date2_index = $date2"

echo ""
echo "[STEP 3] Computing difference..."
calculate_difference $date1 $date2
abs $diff
diff=$value

echo ""
echo "=============================================="
echo "RESULT: $1  →  $2  =  $diff day(s)"
echo "=============================================="
echo $diff
exit 0
