#!/bin/bash
# =============================================================================
# S5: collatz.sh — FULLY ANNOTATED VERSION
# PURPOSE: Generate Collatz (hailstone) sequence from a seed value
# USAGE:   ./s5_collatz_annotated.sh [seed]
# =============================================================================

MAX_ITERATIONS=200

echo "=============================================="
echo "[INIT] collatz.sh — Hailstone / Collatz Sequence"
echo "[INIT] MAX_ITERATIONS: $MAX_ITERATIONS"

h=${1:-$$}   # Use PID as seed if none given
echo "[INIT] Seed value h=$h (from ${1:+argument}${1:-PID})"
echo "=============================================="
echo ""

echo "C($h) -*- $MAX_ITERATIONS Iterations"
echo ""

echo "[PROBE 1] Beginning iteration loop..."
max_val=$h
min_val=$h
even_count=0
odd_count=0

for ((i=1; i<=MAX_ITERATIONS; i++)); do
    # Show detailed state for first 5 iterations
    if [ $i -le 5 ]; then
        echo "[PROBE 2] Step $i: h=$h, parity=$(( h % 2 == 0 ? 0 : 1 )) ($(( h % 2 == 0 ? 0 : 1 ))==0 means even)"
    fi

    printf "%7d" $h

    let "remainder = h % 2"

    if [ "$remainder" -eq 0 ]; then
        let "h /= 2"
        (( even_count++ ))
        [ $i -le 5 ] && echo "[PROBE 3]   EVEN: divided by 2 → h=$h"
    else
        let "h = h*3 + 1"
        (( odd_count++ ))
        [ $i -le 5 ] && echo "[PROBE 3]   ODD: 3n+1 → h=$h"
    fi

    # Track statistics
    [ $h -gt $max_val ] && max_val=$h
    [ $h -lt $min_val ] && min_val=$h

    COLUMNS=10
    let "line_break = i % $COLUMNS"
    [ "$line_break" -eq 0 ] && echo

    # Check for cycle detection (4,2,1 means sequence has converged)
    if [ $i -gt 3 ] && [ $h -eq 1 ]; then
        echo ""
        echo "[PROBE 4] Convergence detected at step $i! Sequence reached 1."
        break
    fi
done

echo ""
echo "=============================================="
echo "[PROBE 5] STATISTICS:"
echo "          Even steps: $even_count"
echo "          Odd  steps: $odd_count"
echo "          Max value reached: $max_val"
echo "          Min value reached: $min_val"
echo "          Final value: $h"
echo "=============================================="
exit 0
