=================================================================
PAPER 1 — Shell Script Analysis & Optimization
Script Package — CEN/SWE Operating Systems 2025-2026
=================================================================
REQUIREMENTS: Linux with Bash 4.4+  (Ubuntu 20.04+)

SCRIPTS (14 files):
  s1_mailformat_annotated.sh    — mail-format: 7 debug probes
  s1_mailformat_optimized.sh    — sed|fold → single awk
  s2_rn_annotated.sh            — rn: file renaming probes
  s2_rn_optimized.sh            — sed → ${//} (8.3x faster)
  s3_blankrn_annotated.sh       — blank-rename probes
  s3_blankrn_optimized.sh       — grep+sed → builtin
  s4_encryptedpw_annotated.sh   — security analysis probes
  s5_collatz_annotated.sh       — convergence detection
  s5_collatz_optimized.sh       — builtin printf + bitwise (-96%)
  s6_daysbetween_annotated.sh   — Gauss formula step trace
  s7_gameoflife_annotated.sh    — cell-by-cell generation trace
  s8_modular_annotated.sh       — constraint probes
  s8_crt_optimized.sh           — CRT O(1) formula
  s9_pipeline_annotated.sh      — pipeline stage analysis
  s10_javacounter_annotated.sh  — fork comparison demo
  run_all_benchmarks.sh         — auto-times all, outputs CSV

HOW TO RUN:
  chmod +x *.sh
  bash s5_collatz_annotated.sh 27          # screenshot this
  bash s8_modular_annotated.sh             # screenshot this
  bash s7_gameoflife_annotated.sh          # screenshot this
  bash s1_mailformat_annotated.sh benchmark_results/test_email.txt
  bash run_all_benchmarks.sh               # full timing suite

10 SCRIPTS SELECTED (from ABS Guide Sections 1,2,3):
  S1=mailformat  S2=rn  S3=blank-rename  S4=encryptedpw
  S5=collatz  S6=days-between  S7=Game-of-Life
  S8=modular-arith  S9=file-type-pipe  S10=java-counter
=================================================================
