#!/bin/bash
# =============================================================================
# run_all_benchmarks.sh
# Master benchmark runner for Paper 1 — Shell Script Analysis
# =============================================================================
# USAGE:   ./run_all_benchmarks.sh
# OUTPUT:  Creates benchmark_results/ folder with:
#            - timing data for each script (original + optimized)
#            - strace system-call summaries
#            - memory usage reports
#            - comparison CSV: benchmark_summary.csv
# =============================================================================
# REQUIREMENTS: bash 4+, strace, /usr/bin/time (from package 'time' on Ubuntu)
# Install:  sudo apt-get install -y strace time
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RESULTS="$SCRIPT_DIR/benchmark_results"
RUNS=10          # Number of runs per script (use 30 for paper-quality data)
SEED=27          # Collatz seed

mkdir -p "$RESULTS"
CSV="$RESULTS/benchmark_summary.csv"

echo "id,script,version,run,wall_sec,user_sec,sys_sec,max_rss_kb,forks" > "$CSV"

RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'
BOLD='\033[1m'; NC='\033[0m'

banner() {
    echo ""
    echo -e "${BOLD}${BLUE}══════════════════════════════════════════${NC}"
    echo -e "${BOLD}${BLUE}  $1${NC}"
    echo -e "${BOLD}${BLUE}══════════════════════════════════════════${NC}"
}

# Check dependencies
check_deps() {
    banner "Checking dependencies"
    for cmd in strace bash awk; do
        if command -v "$cmd" &>/dev/null; then
            echo -e "  ${GREEN}✓${NC} $cmd found: $(command -v $cmd)"
        else
            echo -e "  ${RED}✗${NC} $cmd NOT found"
        fi
    done
    # /usr/bin/time is separate from bash builtin time
    if [ -x /usr/bin/time ]; then
        echo -e "  ${GREEN}✓${NC} /usr/bin/time found"
    else
        echo -e "  ${RED}✗${NC} /usr/bin/time not found — install with: sudo apt-get install time"
    fi
    echo "  Bash version: $BASH_VERSION"
    echo "  Kernel: $(uname -r)"
    echo "  CPU: $(grep 'model name' /proc/cpuinfo | head -1 | cut -d: -f2 | xargs)"
    echo "  RAM: $(free -h | awk '/^Mem:/{print $2}')"
}

# ── Generic timed run ────────────────────────────────────────────────────────
# Args: id  script_label  version  cmd...
timed_run() {
    local id=$1 label=$2 version=$3; shift 3
    local tmpout="$RESULTS/${id}_${version}.tmp"
    local timefile="$RESULTS/${id}_${version}_time.txt"
    local stracefile="$RESULTS/${id}_${version}_strace.txt"

    echo -e "  ${BLUE}→${NC} Running: $label [$version] × $RUNS iterations"

    local total_wall=0 total_user=0 total_sys=0 total_rss=0

    for ((run=1; run<=RUNS; run++)); do
        # /usr/bin/time -f gives structured output
        if /usr/bin/time -f "WALL=%e USER=%U SYS=%S RSS=%M" \
            bash "$@" > "$tmpout" 2>"$timefile" ; then
            :
        fi
        local wall=$(grep -o 'WALL=[0-9.]*' "$timefile" | cut -d= -f2)
        local user=$(grep -o 'USER=[0-9.]*' "$timefile" | cut -d= -f2)
        local sys=$(grep -o 'SYS=[0-9.]*'  "$timefile" | cut -d= -f2)
        local rss=$(grep -o 'RSS=[0-9]*'   "$timefile" | cut -d= -f2)

        wall=${wall:-0}; user=${user:-0}; sys=${sys:-0}; rss=${rss:-0}
        total_wall=$(awk "BEGIN{print $total_wall + $wall}")
        total_user=$(awk "BEGIN{print $total_user + $user}")
        total_sys=$(awk "BEGIN{print $total_sys  + $sys}")
        total_rss=$(awk "BEGIN{print $total_rss  + $rss}")

        echo "    Run $run: wall=${wall}s  user=${user}s  sys=${sys}s  rss=${rss}KB"
        echo "$id,$label,$version,$run,$wall,$user,$sys,$rss,?" >> "$CSV"
    done

    # Averages
    avg_wall=$(awk "BEGIN{printf '%.4f', $total_wall/$RUNS}")
    avg_user=$(awk "BEGIN{printf '%.4f', $total_user/$RUNS}")
    avg_sys=$(awk "BEGIN{printf '%.4f', $total_sys/$RUNS}")
    avg_rss=$(awk  "BEGIN{printf '%.0f', $total_rss/$RUNS}")

    echo ""
    echo -e "  ${GREEN}✓ AVG${NC}: wall=${avg_wall}s  user=${avg_user}s  sys=${avg_sys}s  rss=${avg_rss}KB"

    # strace fork count (single run)
    if command -v strace &>/dev/null; then
        strace -e trace=clone,execve -c bash "$@" 2>"$stracefile" >/dev/null
        echo "  strace summary saved → $stracefile"
    fi
}

# ── Create test files/dirs ───────────────────────────────────────────────────
setup_test_env() {
    banner "Setting up test environment"
    mkdir -p "$RESULTS/test_dir_rn" "$RESULTS/test_dir_blanks"

    # Test file for mailformat
    cat > "$RESULTS/test_email.txt" << 'EMAILEOF'
> This is a quoted line that needs caret removal.
> > Deeply nested quoted line.
This is a very very very long line that absolutely needs to be folded because it exceeds the seventy character width limit set in the script.
Normal line here.
  > Another quoted line with leading spaces.
EMAILEOF
    echo "  Created: test_email.txt ($(wc -l < "$RESULTS/test_email.txt") lines)"

    # Test files for rn.sh (gif → jpg renaming)
    for i in $(seq 1 20); do
        touch "$RESULTS/test_dir_rn/image_${i}.gif"
    done
    echo "  Created: 20 .gif files in test_dir_rn/"

    # Test files for blank-rename
    for i in $(seq 1 20); do
        touch "$RESULTS/test_dir_blanks/file with spaces $i.txt"
    done
    echo "  Created: 20 files with spaces in test_dir_blanks/"

    # Test Java files
    mkdir -p "$RESULTS/src"
    for i in $(seq 1 50); do
        {   echo "// Java file $i"
            echo "public class File$i {"
            for j in $(seq 1 20); do
                echo "    // Line $j"
            done
            echo "}"
        } > "$RESULTS/src/File${i}.java"
    done
    echo "  Created: 50 Java source files (22 lines each)"
}

# ── Individual benchmarks ────────────────────────────────────────────────────

bench_mailformat() {
    banner "S1: mail-format.sh"
    chmod +x "$SCRIPT_DIR/s1_mailformat_annotated.sh" \
             "$SCRIPT_DIR/s1_mailformat_optimized.sh" 2>/dev/null || true

    # Suppress debug output for clean timing
    echo "  [Original — sed|fold pipeline]"
    cat > "$RESULTS/s1_orig.sh" << 'EOF'
#!/bin/bash
MAXWIDTH=70
sedscript='s/^>//
s/^ *>//
s/^ *//
s/ *//'
sed "$sedscript" "$1" | fold -s --width=$MAXWIDTH
EOF
    chmod +x "$RESULTS/s1_orig.sh"
    timed_run S1 "mailformat" "original" "$RESULTS/s1_orig.sh" "$RESULTS/test_email.txt"

    echo "  [Optimized — single awk]"
    timed_run S1 "mailformat" "optimized" "$SCRIPT_DIR/s1_mailformat_optimized.sh" "$RESULTS/test_email.txt"
}

bench_collatz() {
    banner "S5: collatz.sh"

    # Original (using /usr/bin/printf path)
    cat > "$RESULTS/s5_orig.sh" << EOF
#!/bin/bash
MAX_ITERATIONS=200; h=${SEED}
for ((i=1; i<=MAX_ITERATIONS; i++)); do
    printf "%7d" \$h
    let "remainder = h % 2"
    if [ "\$remainder" -eq 0 ]; then let "h /= 2"
    else let "h = h*3 + 1"; fi
    let "line_break = i % 10"
    [ "\$line_break" -eq 0 ] && echo
done; echo
EOF
    chmod +x "$RESULTS/s5_orig.sh"
    echo "  [Original — external printf, 200 forks]"
    timed_run S5 "collatz" "original" "$RESULTS/s5_orig.sh"

    echo "  [Optimized — builtin printf, 0 forks]"
    timed_run S5 "collatz" "optimized" "$SCRIPT_DIR/s5_collatz_optimized.sh" "$SEED"
}

bench_modular() {
    banner "S8: Modular Arithmetic (CRT)"

    cat > "$RESULTS/s8_brute.sh" << 'EOF'
#!/bin/bash
MAX=10000
for ((nr=1; nr<$MAX; nr++)); do
    let "t1 = nr % 5"; [ "$t1" -ne 3 ] && continue
    let "t2 = nr % 7"; [ "$t2" -ne 4 ] && continue
    let "t3 = nr % 9"; [ "$t3" -ne 5 ] && continue
    break
done
echo "Number = $nr"
EOF
    chmod +x "$RESULTS/s8_brute.sh"
    echo "  [Original — brute force O(N)]"
    timed_run S8 "modular" "brute_force" "$RESULTS/s8_brute.sh"

    echo "  [Optimized — CRT O(1)]"
    cat > "$RESULTS/s8_crt.sh" << 'EOF'
#!/bin/bash
n=$(( (3*63*2 + 4*45*5 + 5*35*8) % 315 ))
echo "Number = $n"
EOF
    chmod +x "$RESULTS/s8_crt.sh"
    timed_run S8 "modular" "CRT_O1" "$RESULTS/s8_crt.sh"
}

bench_javacounter() {
    banner "S10: Java Line Counter"

    cat > "$RESULTS/s10_orig.sh" << EOF
#!/bin/bash
SRC="$RESULTS/src"
export SUM=0
for f in \$(find "\$SRC" -name "*.java"); do
    export SUM=\$((\$SUM + \$(wc -l "\$f" | awk '{print \$1}')))
done
echo \$SUM
EOF
    chmod +x "$RESULTS/s10_orig.sh"
    echo "  [Original — 2N forks]"
    timed_run S10 "java_counter" "original" "$RESULTS/s10_orig.sh"

    cat > "$RESULTS/s10_opt.sh" << EOF
#!/bin/bash
SRC="$RESULTS/src"
find "\$SRC" -name "*.java" -print0 | xargs -0 wc -l 2>/dev/null | tail -1 | awk '{print \$1}'
EOF
    chmod +x "$RESULTS/s10_opt.sh"
    echo "  [Optimized — 4 forks constant]"
    timed_run S10 "java_counter" "optimized" "$RESULTS/s10_opt.sh"
}

bench_rn() {
    banner "S2: rn.sh"
    # rn.sh needs files to rename — use copies
    mkdir -p "$RESULTS/rn_orig_test" "$RESULTS/rn_opt_test"
    for i in $(seq 1 50); do
        touch "$RESULTS/rn_orig_test/image_${i}.gif"
        touch "$RESULTS/rn_opt_test/image_${i}.gif"
    done

    cat > "$RESULTS/s2_orig.sh" << 'EOF'
#!/bin/bash
DIR=$1; PAT=$2; REP=$3
number=0
for filename in "$DIR"/*"$PAT"*; do
    [ -f "$filename" ] || continue
    fname=$(basename "$filename")
    n=$(echo "$fname" | sed -e "s/$PAT/$REP/")
    mv "$filename" "$(dirname $filename)/$n"
    let "number += 1"
done
echo "$number files renamed."
EOF
    chmod +x "$RESULTS/s2_orig.sh"

    # Restore files before each run is complex; run once for comparison
    echo "  Note: rn.sh modifies filesystem — running single comparative test"
    echo "  [Original — sed fork per file]"
    start=$(date +%s%N)
    bash "$RESULTS/s2_orig.sh" "$RESULTS/rn_orig_test" "gif" "jpg" > /dev/null
    end=$(date +%s%N)
    echo "  Original (50 files): $(( (end - start) / 1000000 ))ms"

    for i in $(seq 1 50); do touch "$RESULTS/rn_opt_test/image_${i}.gif"; done
    cat > "$RESULTS/s2_opt.sh" << 'EOF'
#!/bin/bash
DIR=$1; PAT=$2; REP=$3
number=0
for filename in "$DIR"/*"$PAT"*; do
    [ -f "$filename" ] || continue
    n="${filename//$PAT/$REP}"
    [ "$n" != "$filename" ] && mv -- "$filename" "$n" && (( number++ ))
done
echo "$number files renamed."
EOF
    chmod +x "$RESULTS/s2_opt.sh"
    start=$(date +%s%N)
    bash "$RESULTS/s2_opt.sh" "$RESULTS/rn_opt_test" "gif" "jpg" > /dev/null
    end=$(date +%s%N)
    echo "  Optimized (50 files): $(( (end - start) / 1000000 ))ms"
}

# ── Generate summary report ──────────────────────────────────────────────────
generate_report() {
    banner "Generating benchmark report"
    local report="$RESULTS/BENCHMARK_REPORT.txt"
    {
        echo "════════════════════════════════════════════════════════"
        echo "  BENCHMARK REPORT — Paper 1: Shell Script Analysis"
        echo "  Generated: $(date)"
        echo "  System: $(uname -a)"
        echo "  Bash: $BASH_VERSION"
        echo "  Runs per script: $RUNS"
        echo "════════════════════════════════════════════════════════"
        echo ""
        echo "Results are in: benchmark_summary.csv"
        echo ""
        echo "HOW TO USE THESE RESULTS IN YOUR PAPER:"
        echo "  1. Open benchmark_summary.csv in Excel/LibreOffice"
        echo "  2. Calculate averages per (script, version)"
        echo "  3. Compute speedup = original_time / optimized_time"
        echo "  4. Insert into Paper 1 tables (Section 8)"
        echo "  5. Take screenshots of your terminal showing these results"
        echo ""
        echo "STRACE FILES (system-call counts):"
        ls "$RESULTS"/*strace*.txt 2>/dev/null | while read f; do
            echo "  $f"
        done
        echo ""
        echo "CSV DATA:"
        cat "$CSV"
    } > "$report"
    echo "  Report saved: $report"
    echo "  CSV saved:    $CSV"
}

# ── MAIN ─────────────────────────────────────────────────────────────────────
main() {
    banner "Paper 1 — Master Benchmark Runner"
    echo "  Results directory: $RESULTS"
    echo "  Runs per test: $RUNS"
    echo "  Collatz seed: $SEED"

    check_deps
    setup_test_env
    bench_mailformat
    bench_collatz
    bench_modular
    bench_javacounter
    bench_rn
    generate_report

    banner "ALL BENCHMARKS COMPLETE"
    echo ""
    echo -e "  ${GREEN}✓${NC} Results in:  $RESULTS/"
    echo -e "  ${GREEN}✓${NC} CSV data:    $CSV"
    echo ""
    echo "  NEXT STEPS FOR YOUR PAPER:"
    echo "  ① Take a screenshot of THIS terminal output"
    echo "  ② Open benchmark_results/BENCHMARK_REPORT.txt"
    echo "  ③ Run individual annotated scripts and screenshot their output:"
    echo "       bash s5_collatz_annotated.sh 27"
    echo "       bash s8_modular_annotated.sh"
    echo "       bash s1_mailformat_annotated.sh benchmark_results/test_email.txt"
    echo "  ④ Insert screenshots into the Word document"
}

main "$@"
