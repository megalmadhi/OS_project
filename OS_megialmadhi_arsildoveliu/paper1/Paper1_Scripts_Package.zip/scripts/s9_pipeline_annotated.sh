#!/bin/bash
# =============================================================================
# S9: file-type-pipeline.sh — FULLY ANNOTATED
# Pipeline: file | fgrep | tee | wc -l
# =============================================================================
DIRNAME=/usr/bin
FILETYPE="shell script"
LOGFILE=/tmp/shellscripts_paper1.log

echo "=============================================="
echo "[INIT] File-Type Pipeline Script"
echo "[INIT] Scanning: $DIRNAME  |  Type: '$FILETYPE'"
echo "=============================================="

total_files=$(ls "$DIRNAME" | wc -l)
echo "[PROBE 1] Total files in $DIRNAME: $total_files"
echo "[PROBE 2] Starting: file | fgrep | tee | wc -l"
echo "[PROBE 3] All 4 stages run as parallel processes via kernel pipes"
echo ""

count=$(file "$DIRNAME"/* | fgrep "$FILETYPE" | tee "$LOGFILE" | wc -l)

echo ""
echo "[PROBE 4] Pipeline complete"
echo "[PROBE 5] Shell scripts found: $count"
echo "[PROBE 6] First 5 log entries:"
head -5 "$LOGFILE" 2>/dev/null | sed 's/^/   /'
echo ""
echo "RESULT: $count shell scripts in $DIRNAME"
echo ""
echo "--- OPTIMIZED (grep -c replaces fgrep+wc) ---"
opt=$(file "$DIRNAME"/* | grep -c "$FILETYPE")
echo "Optimized result: $opt (same answer, 1 fewer process)"
