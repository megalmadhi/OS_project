"""
mlfq_simulator.py
Multilevel Feedback Queue (MLFQ) Simulator
Paper 3 — Scheduling, Queuing & System Optimization

3-Level MLFQ:
  Level 1: Round-Robin, quantum Q1, time budget L1
  Level 2: Round-Robin, quantum Q2, time budget L2
  Level 3: Hybrid — SJF for T% of budget, FCFS for (100-T)% of budget
           Total Level-3 budget = TOTAL_TIME - L1 - L2

Parameters:
  Q1, Q2   : time quanta (ms)
  L1, L2   : time allocations per 100ms cycle (ms)
  T        : % of Level-3 time given to SJF (0-100)
  N        : number of processes per simulation
  M        : max arrival time (processes arrive in [0, M])
  dist     : arrival/burst distribution ('uniform','exponential','poisson')

Metrics: throughput, avg_turnaround, avg_waiting, avg_response
"""

import random
import math
import numpy as np
from dataclasses import dataclass, field
from typing import List, Optional
from collections import deque

TOTAL_TIME = 100  # ms per scheduling cycle (L1 + L2 + L3 = 100)

@dataclass
class Process:
    pid:        int
    arrival:    float       # time of arrival
    burst:      float       # total CPU needed (ms)
    remaining:  float = 0.0 # remaining CPU time
    start:      float = -1.0# first time scheduled
    finish:     float = -1.0# completion time
    level:      int   = 1   # current queue level (1,2,3)
    time_in_level: float = 0.0  # time spent at current level

    def __post_init__(self):
        self.remaining = self.burst

    @property
    def turnaround(self): return self.finish - self.arrival
    @property
    def waiting(self):    return self.turnaround - self.burst
    @property
    def response(self):   return (self.start - self.arrival) if self.start >= 0 else 0.0


def generate_processes(N: int, M: float, dist: str = 'uniform', seed: int = None) -> List[Process]:
    """Generate N processes with random burst times and arrivals."""
    rng = random.Random(seed) if seed is not None else random.Random()

    if dist == 'uniform':
        bursts   = [rng.uniform(10, 1000) for _ in range(N)]
        arrivals = sorted([rng.uniform(0, M) for _ in range(N)])

    elif dist == 'exponential':
        mean_burst   = 200.0
        mean_interarr = M / N if N > 0 else 1.0
        bursts   = [min(1000, max(10, rng.expovariate(1/mean_burst))) for _ in range(N)]
        # Poisson process arrivals (exponential inter-arrivals)
        arrivals = []
        t = 0.0
        for _ in range(N):
            t += rng.expovariate(1/mean_interarr)
            arrivals.append(t)

    elif dist == 'poisson':
        # Burst times from gamma distribution (sum of exponentials)
        mean_burst = 200.0
        bursts = [min(1000, max(10, rng.gammavariate(2, mean_burst/2))) for _ in range(N)]
        # Uniform arrivals with Poisson-like clustering
        arrivals = sorted([rng.uniform(0, M) for _ in range(N)])

    else:
        raise ValueError(f"Unknown distribution: {dist}")

    return [Process(pid=i, arrival=arrivals[i], burst=bursts[i]) for i in range(N)]


def run_mlfq(processes: List[Process], Q1: float, Q2: float,
             L1: float, L2: float, T: float) -> dict:
    """
    Run MLFQ simulation on a list of processes.
    Returns metrics dict.
    """
    L3 = TOTAL_TIME - L1 - L2
    if L3 < 0:
        L3 = 0.0

    # Deep copy processes to avoid mutation
    procs = [Process(p.pid, p.arrival, p.burst) for p in processes]
    total_procs = len(procs)

    # Ready queues
    q1 = deque()   # Level 1: RR Q1
    q2 = deque()   # Level 2: RR Q2
    q3_sjf = []    # Level 3 SJF portion (sorted by remaining time)
    q3_fcfs = deque()  # Level 3 FCFS portion

    # Sort by arrival
    procs.sort(key=lambda p: p.arrival)
    arrival_idx = 0
    current_time = 0.0
    completed = []

    def admit_arrivals(up_to_time):
        nonlocal arrival_idx
        while arrival_idx < len(procs) and procs[arrival_idx].arrival <= up_to_time:
            q1.append(procs[arrival_idx])
            arrival_idx += 1

    def run_queue_rr(queue, quantum, budget, time_now):
        """Run Round-Robin on `queue` for `budget` ms total, quantum=`quantum`."""
        time_used = 0.0
        new_demotions = []  # (level, proc) to re-queue at higher level

        while queue and time_used < budget:
            p = queue.popleft()
            admit_arrivals(time_now + time_used)

            # How much can we give this process?
            slot = min(quantum, p.remaining, budget - time_used)
            if slot <= 0:
                queue.appendleft(p)
                break

            if p.start < 0:
                p.start = time_now + time_used
            p.remaining -= slot
            p.time_in_level += slot
            time_used += slot

            admit_arrivals(time_now + time_used)

            if p.remaining <= 1e-9:
                p.finish = time_now + time_used
                completed.append(p)
            else:
                # Demote if used full quantum
                if slot >= quantum - 1e-9:
                    new_demotions.append(p)
                else:
                    queue.appendleft(p)  # re-queue at same level (partial)

        return time_used, new_demotions

    def run_queue_sjf(procs_list, budget, time_now):
        """Run SJF on procs_list for budget ms."""
        time_used = 0.0
        procs_list.sort(key=lambda p: p.remaining)  # shortest remaining first

        while procs_list and time_used < budget:
            p = procs_list[0]
            admit_arrivals(time_now + time_used)
            slot = min(p.remaining, budget - time_used)
            if slot <= 0: break
            if p.start < 0:
                p.start = time_now + time_used
            p.remaining -= slot
            time_used += slot
            admit_arrivals(time_now + time_used)
            if p.remaining <= 1e-9:
                p.finish = time_now + time_used
                completed.append(p)
                procs_list.pop(0)
            else:
                procs_list.sort(key=lambda x: x.remaining)

        return time_used

    def run_queue_fcfs(queue, budget, time_now):
        """Run FCFS on queue for budget ms."""
        time_used = 0.0
        while queue and time_used < budget:
            p = queue[0]
            admit_arrivals(time_now + time_used)
            slot = min(p.remaining, budget - time_used)
            if slot <= 0: break
            if p.start < 0:
                p.start = time_now + time_used
            p.remaining -= slot
            time_used += slot
            admit_arrivals(time_now + time_used)
            if p.remaining <= 1e-9:
                p.finish = time_now + time_used
                completed.append(p)
                queue.popleft()

        return time_used

    # Run scheduling cycles until all processes complete
    max_cycles = int(max(p.burst for p in procs) * 2 / TOTAL_TIME) + len(procs) + 50
    cycle = 0

    while (len(completed) < total_procs) and cycle < max_cycles:
        admit_arrivals(current_time)
        cycle_start = current_time

        # --- Level 1: RR with Q1 ---
        used1, demoted1 = run_queue_rr(q1, Q1, L1, current_time)
        current_time = cycle_start + used1
        for p in demoted1:
            p.level = 2
            q2.append(p)
        admit_arrivals(current_time)

        # --- Level 2: RR with Q2 ---
        used2, demoted2 = run_queue_rr(q2, Q2, L2, current_time)
        current_time = cycle_start + L1 + used2
        for p in demoted2:
            p.level = 3
            # Decide SJF vs FCFS bucket based on T
            if random.random() * 100 < T:
                q3_sjf.append(p)
            else:
                q3_fcfs.append(p)
        admit_arrivals(current_time)

        # --- Level 3: T% SJF + (100-T)% FCFS ---
        sjf_budget  = L3 * T / 100.0
        fcfs_budget = L3 * (100 - T) / 100.0

        used3a = run_queue_sjf(q3_sjf, sjf_budget, current_time)
        current_time = cycle_start + L1 + L2 + used3a

        used3b = run_queue_fcfs(q3_fcfs, fcfs_budget, current_time)
        current_time = cycle_start + L1 + L2 + used3a + used3b

        # Advance to next cycle start
        current_time = cycle_start + TOTAL_TIME
        cycle += 1

        # Re-admit any late arrivals
        admit_arrivals(current_time)

    # Handle any remaining incomplete processes (mark as timed out for stats)
    for p in list(q1) + list(q2) + q3_sjf + list(q3_fcfs):
        if p.finish < 0:
            p.finish = current_time

    completed.extend([p for p in procs if p.finish > 0 and p not in completed])

    if not completed:
        return {"throughput":0,"avg_turnaround":9999,"avg_waiting":9999,"avg_response":9999}

    n = len(completed)
    total_time_span = current_time if current_time > 0 else 1
    throughput   = n / total_time_span * 1000  # processes per second
    avg_tat      = sum(max(0, p.turnaround) for p in completed) / n
    avg_wait     = sum(max(0, p.waiting)    for p in completed) / n
    avg_resp     = sum(max(0, p.response)   for p in completed) / n

    return {
        "throughput":    throughput,
        "avg_turnaround": avg_tat,
        "avg_waiting":   avg_wait,
        "avg_response":  avg_resp,
        "n_completed":   n,
        "cycles":        cycle,
    }


def monte_carlo(Q1, Q2, L1, L2, T, N=500, M=100, n_trials=50, dist='uniform'):
    """Run n_trials independent simulations, return averaged metrics."""
    results = {"throughput":[], "avg_turnaround":[], "avg_waiting":[], "avg_response":[]}
    for trial in range(n_trials):
        procs = generate_processes(N, M, dist=dist, seed=trial*7+Q1*3+Q2)
        r = run_mlfq(procs, Q1, Q2, L1, L2, T)
        for k in results: results[k].append(r[k])
    return {k: float(np.mean(v)) for k, v in results.items()}


if __name__ == "__main__":
    import sys
    Q1 = float(sys.argv[1]) if len(sys.argv)>1 else 8
    Q2 = float(sys.argv[2]) if len(sys.argv)>2 else 16
    L1 = float(sys.argv[3]) if len(sys.argv)>3 else 20
    L2 = float(sys.argv[4]) if len(sys.argv)>4 else 30
    T  = float(sys.argv[5]) if len(sys.argv)>5 else 50
    N  = int(sys.argv[6])   if len(sys.argv)>6 else 200
    M  = int(sys.argv[7])   if len(sys.argv)>7 else 100

    print(f"Running MLFQ: Q1={Q1} Q2={Q2} L1={L1} L2={L2} T={T} N={N} M={M}")
    r = monte_carlo(Q1, Q2, L1, L2, T, N=N, M=M, n_trials=20)
    for k,v in r.items(): print(f"  {k}: {v:.4f}")
