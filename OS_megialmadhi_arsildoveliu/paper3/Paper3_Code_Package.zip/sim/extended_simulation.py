"""
extended_simulation.py
Extended Paper 3 simulation fixing all gaps:
  1. 100-500 Monte Carlo trials (not 25)
  2. N up to 5000 processes
  3. Part A (FCFS only at L3) vs Part B (T% SJF + (100-T)% FCFS) separately
  4. R parameter — system capacity (max processes served per time unit)
  5. M/M/1 and M/M/S quantities vs M, N, R
"""
import sys, os, json, math, random
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from mlfq_simulator import monte_carlo, generate_processes, run_mlfq

OUT = "/home/claude/paper3/results"
os.makedirs(OUT, exist_ok=True)

print("=" * 65)
print("PAPER 3 — EXTENDED SIMULATION (full requirements)")
print("=" * 65)

# ════════════════════════════════════════════════════════════════════════
# PART A: Level-3 = PURE FCFS (T=0)
# PART B: Level-3 = T% SJF + (100-T)% FCFS
# Run both with 100 trials, N = 100 to 5000
# ════════════════════════════════════════════════════════════════════════
N_TRIALS = 100    # Meets "100-500 simulations" requirement
Q1, Q2, L1, L2 = 8, 16, 10, 20   # optimal from grid search

print("\n[PART A vs B] N=100–5000, 100 trials each")
partA_results = {}   # T=0 (pure FCFS at Level-3)
partB_results = {}   # T=80 (80% SJF at Level-3 — near-optimal)

for N in [100, 200, 500, 1000, 2000, 5000]:
    M_arr = max(50, N // 10)   # arrival window scales with N

    print(f"\n  N={N}, M={M_arr}, {N_TRIALS} trials:")

    # Part A: pure FCFS (T=0)
    rA = monte_carlo(Q1, Q2, L1, L2, T=0,
                     N=N, M=M_arr, n_trials=N_TRIALS, dist='uniform')
    partA_results[str(N)] = {"N":N,"M":M_arr,"T":0, **rA}
    print(f"    Part A (T=0%  FCFS): "
          f"thr={rA['throughput']:.2f}/s "
          f"tat={rA['avg_turnaround']:.0f}ms "
          f"wait={rA['avg_waiting']:.0f}ms "
          f"resp={rA['avg_response']:.0f}ms")

    # Part B: T=80% SJF
    rB = monte_carlo(Q1, Q2, L1, L2, T=80,
                     N=N, M=M_arr, n_trials=N_TRIALS, dist='uniform')
    partB_results[str(N)] = {"N":N,"M":M_arr,"T":80, **rB}
    print(f"    Part B (T=80% SJF): "
          f"thr={rB['throughput']:.2f}/s "
          f"tat={rB['avg_turnaround']:.0f}ms "
          f"wait={rB['avg_waiting']:.0f}ms "
          f"resp={rB['avg_response']:.0f}ms")

# ════════════════════════════════════════════════════════════════════════
# R PARAMETER: M/M/1 and M/M/S with service capacity R
# ════════════════════════════════════════════════════════════════════════
print("\n[M/M/1 and M/M/S with R] Varying N, M, R")

def mm1_with_R(N, M, R):
    """
    M/M/1 where server rate is capped at R processes per time unit.
    lambda = N/M (arrival rate, processes per ms)
    mu     = R   (service rate = R processes per time unit)
    rho    = lambda / mu
    """
    lam = N / M       # arrival rate
    mu  = R           # service capacity per time unit
    rho = lam / mu
    if rho >= 1.0:
        return {"N":N,"M":M,"R":R,"lam":lam,"mu":mu,"rho":rho,
                "stable":False,"L":float('inf'),"Lq":float('inf'),
                "W":float('inf'),"Wq":float('inf'),"P0":0.0}
    P0  = 1 - rho
    L   = rho / (1 - rho)
    Lq  = rho**2 / (1 - rho)
    W   = 1 / (mu - lam)
    Wq  = rho / (mu - lam)
    return {"N":N,"M":M,"R":R,"lam":round(lam,4),"mu":mu,"rho":round(rho,4),
            "stable":True,"L":round(L,3),"Lq":round(Lq,3),
            "W":round(W,3),"Wq":round(Wq,3),"P0":round(P0,3)}

def mms_with_R(N, M, R, s):
    """
    M/M/S where total service rate = R processes per time unit, split over s servers.
    mu_per_server = R / s
    """
    lam = N / M
    mu  = R / s       # each server handles R/s processes per time unit
    rho = lam / (s * mu)   # per-server utilization
    if rho >= 1.0:
        return {"N":N,"M":M,"R":R,"s":s,"rho":rho,"stable":False}

    # Erlang-C
    a = lam / mu  # total offered load
    try:
        sum_terms = sum(a**k / math.factorial(k) for k in range(s))
        last_term  = (a**s / math.factorial(s)) * (1 / (1 - rho))
        Csa = last_term / (sum_terms + last_term)
    except (OverflowError, ZeroDivisionError):
        Csa = 1.0

    Lq  = Csa * rho / (1 - rho)
    L   = Lq + lam / mu
    Wq  = Lq / lam if lam > 0 else 0
    W   = Wq + 1 / mu
    return {"N":N,"M":M,"R":R,"s":s,"rho":round(rho,4),"stable":True,
            "Csa":round(Csa,4),"L":round(L,3),"Lq":round(Lq,4),
            "W":round(W,3),"Wq":round(Wq,4)}

# ── Vary N (process count) with fixed M=100, R=10 ──────────────────────
mm1_vs_N = []
N_vals = [50, 100, 200, 300, 500, 800, 1000]
M_fixed, R_fixed = 100, 10
print(f"\n  M/M/1 vs N (M={M_fixed}, R={R_fixed}):")
for N in N_vals:
    r = mm1_with_R(N, M_fixed, R_fixed)
    mm1_vs_N.append(r)
    status = "STABLE  " if r["stable"] else "UNSTABLE"
    if r["stable"]:
        print(f"    N={N:5d}: rho={r['rho']:.3f} L={r['L']:.2f} Lq={r['Lq']:.2f} "
              f"W={r['W']:.2f}ms [{status}]")
    else:
        print(f"    N={N:5d}: rho={r['rho']:.2f} [{status}]")

# ── Vary M (arrival window) with fixed N=200, R=10 ─────────────────────
mm1_vs_M = []
M_vals = [20, 30, 50, 80, 100, 150, 200, 300]
N_fixed, R_fixed2 = 200, 10
print(f"\n  M/M/1 vs M (N={N_fixed}, R={R_fixed2}):")
for M in M_vals:
    r = mm1_with_R(N_fixed, M, R_fixed2)
    mm1_vs_M.append(r)
    status = "STABLE  " if r["stable"] else "UNSTABLE"
    if r["stable"]:
        print(f"    M={M:5d}: lam={r['lam']:.3f} rho={r['rho']:.3f} "
              f"L={r['L']:.2f} W={r['W']:.2f}ms [{status}]")
    else:
        print(f"    M={M:5d}: lam={r['lam']:.3f} rho={r['rho']:.2f} [{status}]")

# ── Vary R (service capacity) with fixed N=200, M=100 ──────────────────
mm1_vs_R = []
R_vals = [1, 2, 3, 5, 8, 10, 15, 20, 30, 50]
N_fixed2, M_fixed2 = 200, 100
print(f"\n  M/M/1 vs R (N={N_fixed2}, M={M_fixed2}):")
for R in R_vals:
    r = mm1_with_R(N_fixed2, M_fixed2, R)
    mm1_vs_R.append(r)
    status = "STABLE  " if r["stable"] else "UNSTABLE"
    if r["stable"]:
        print(f"    R={R:5d}: rho={r['rho']:.4f} L={r['L']:.4f} "
              f"Lq={r['Lq']:.4f} W={r['W']:.3f}ms [{status}]")
    else:
        print(f"    R={R:5d}: rho={r['rho']:.2f} [{status}]")

# ── M/M/S vs R for s=1,2,4,8 ───────────────────────────────────────────
mms_vs_R = []
print(f"\n  M/M/S vs R (N={N_fixed2}, M={M_fixed2}, s=1,2,4,8):")
for R in [5, 10, 15, 20, 30]:
    for s in [1, 2, 4, 8]:
        r = mms_with_R(N_fixed2, M_fixed2, R, s)
        mms_vs_R.append(r)
        if r["stable"]:
            print(f"    R={R:3d} s={s}: rho={r['rho']:.4f} "
                  f"L={r['L']:.3f} Wq={r['Wq']:.4f}ms")
        else:
            print(f"    R={R:3d} s={s}: UNSTABLE rho={r['rho']:.2f}")

# ── Stability region: find minimum R for stability given N, M ──────────
stability = []
print(f"\n  Minimum R for stability (rho<1) vs N, M:")
for N in [100, 200, 500, 1000, 2000]:
    for M in [50, 100, 200]:
        lam = N / M
        R_min = math.ceil(lam) + 1  # minimum integer R for rho < 1
        r_check = mm1_with_R(N, M, R_min)
        stability.append({"N":N,"M":M,"lam":round(lam,3),"R_min":R_min,
                           "rho_at_Rmin":round(r_check.get("rho",999),4)})
        print(f"    N={N:5d} M={M:5d}: lam={lam:.2f}/ms → R_min={R_min}")

# ── Save extended results ───────────────────────────────────────────────
extended = {
    "partA": partA_results,
    "partB": partB_results,
    "mm1_vs_N": mm1_vs_N,
    "mm1_vs_M": mm1_vs_M,
    "mm1_vs_R": mm1_vs_R,
    "mms_vs_R": mms_vs_R,
    "stability": stability,
    "params": {"N_TRIALS": N_TRIALS, "Q1":Q1,"Q2":Q2,"L1":L1,"L2":L2}
}
with open(f"{OUT}/extended_results.json","w") as f:
    json.dump(extended, f, indent=2)
print(f"\nSaved: {OUT}/extended_results.json")
print("=" * 65)
print("EXTENDED SIMULATION COMPLETE")
