"""
grid_search.py
Grid search over MLFQ parameters + M/M/1 and M/M/S queueing theory.
Paper 3 — Scheduling, Queuing & System Optimization
"""

import numpy as np
import json, os, sys, math
sys.path.insert(0, os.path.dirname(__file__))
from mlfq_simulator import monte_carlo, generate_processes, run_mlfq

OUT = "/home/claude/paper3/results"
os.makedirs(OUT, exist_ok=True)

# ═══════════════════════════════════════════════════════════════════════════
# PART A: Grid search over Q1, Q2
# ═══════════════════════════════════════════════════════════════════════════
def grid_search_Q1Q2(N=300, M=100, n_trials=30, dist='uniform'):
    """Grid search Q1 x Q2 with fixed L1=25, L2=35, T=50."""
    Q1_vals = [4, 8, 12, 16, 20, 24, 32]
    Q2_vals = [8, 16, 24, 32, 40, 48, 64]
    L1, L2, T = 25, 35, 50

    results = {}
    print(f"\n[GRID Q1×Q2] N={N}, dist={dist}, trials={n_trials}")
    for Q1 in Q1_vals:
        for Q2 in Q2_vals:
            if Q2 <= Q1: continue  # Q2 must be > Q1 (standard MLFQ)
            key = f"Q1={Q1}_Q2={Q2}"
            r = monte_carlo(Q1, Q2, L1, L2, T, N=N, M=M, n_trials=n_trials, dist=dist)
            results[key] = {"Q1":Q1,"Q2":Q2,"L1":L1,"L2":L2,"T":T, **r}
            print(f"  Q1={Q1:3d} Q2={Q2:3d}: "
                  f"throughput={r['throughput']:.2f}/s "
                  f"tat={r['avg_turnaround']:.1f}ms "
                  f"wait={r['avg_waiting']:.1f}ms "
                  f"resp={r['avg_response']:.1f}ms")
    return results

# ═══════════════════════════════════════════════════════════════════════════
# PART B: Grid search over L1, L2
# ═══════════════════════════════════════════════════════════════════════════
def grid_search_L1L2(N=300, M=100, n_trials=30, dist='uniform'):
    """Grid search L1 x L2 with fixed Q1=8, Q2=16, T=50."""
    L1_vals = [10, 20, 30, 40, 50]
    L2_vals = [10, 20, 30, 40]
    Q1, Q2, T = 8, 16, 50

    results = {}
    print(f"\n[GRID L1×L2] N={N}, dist={dist}, trials={n_trials}")
    for L1 in L1_vals:
        for L2 in L2_vals:
            if L1 + L2 >= 95: continue
            key = f"L1={L1}_L2={L2}"
            r = monte_carlo(Q1, Q2, L1, L2, T, N=N, M=M, n_trials=n_trials, dist=dist)
            results[key] = {"Q1":Q1,"Q2":Q2,"L1":L1,"L2":L2,"T":T, **r}
            print(f"  L1={L1:3d} L2={L2:3d}: "
                  f"throughput={r['throughput']:.2f}/s "
                  f"tat={r['avg_turnaround']:.1f}ms "
                  f"wait={r['avg_waiting']:.1f}ms")
    return results

# ═══════════════════════════════════════════════════════════════════════════
# PART C: Grid search over T (SJF/FCFS split)
# ═══════════════════════════════════════════════════════════════════════════
def grid_search_T(N=300, M=100, n_trials=30, dist='uniform'):
    """Search over T parameter (SJF vs FCFS mix in Level 3)."""
    T_vals = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
    Q1, Q2, L1, L2 = 8, 16, 25, 35

    results = {}
    print(f"\n[GRID T] N={N}, dist={dist}, trials={n_trials}")
    for T in T_vals:
        key = f"T={T}"
        r = monte_carlo(Q1, Q2, L1, L2, T, N=N, M=M, n_trials=n_trials, dist=dist)
        results[key] = {"Q1":Q1,"Q2":Q2,"L1":L1,"L2":L2,"T":T, **r}
        print(f"  T={T:3d}%: "
              f"throughput={r['throughput']:.2f}/s "
              f"tat={r['avg_turnaround']:.1f}ms "
              f"wait={r['avg_waiting']:.1f}ms "
              f"resp={r['avg_response']:.1f}ms")
    return results

# ═══════════════════════════════════════════════════════════════════════════
# PART D: N and M variation (process count and arrival window)
# ═══════════════════════════════════════════════════════════════════════════
def grid_search_NM(n_trials=20, dist='uniform'):
    """Vary N processes and M arrival window."""
    N_vals = [50, 100, 200, 500, 1000]
    M_vals = [50, 100, 200]
    Q1, Q2, L1, L2, T = 8, 16, 25, 35, 50

    results = {}
    print(f"\n[GRID N×M] dist={dist}, trials={n_trials}")
    for N in N_vals:
        for M in M_vals:
            key = f"N={N}_M={M}"
            r = monte_carlo(Q1, Q2, L1, L2, T, N=N, M=M, n_trials=n_trials, dist=dist)
            results[key] = {"N":N,"M":M, **r}
            print(f"  N={N:5d} M={M:5d}: "
                  f"throughput={r['throughput']:.2f}/s "
                  f"tat={r['avg_turnaround']:.1f}ms "
                  f"wait={r['avg_waiting']:.1f}ms")
    return results

# ═══════════════════════════════════════════════════════════════════════════
# PART E: Distribution comparison
# ═══════════════════════════════════════════════════════════════════════════
def compare_distributions(N=300, M=100, n_trials=30):
    """Compare uniform, exponential, Poisson distributions."""
    dists = ['uniform', 'exponential', 'poisson']
    Q1, Q2, L1, L2, T = 8, 16, 25, 35, 50
    results = {}
    print(f"\n[DISTRIBUTIONS] N={N}, trials={n_trials}")
    for dist in dists:
        r = monte_carlo(Q1, Q2, L1, L2, T, N=N, M=M, n_trials=n_trials, dist=dist)
        results[dist] = r
        print(f"  {dist:12s}: throughput={r['throughput']:.2f}/s "
              f"tat={r['avg_turnaround']:.1f}ms "
              f"wait={r['avg_waiting']:.1f}ms "
              f"resp={r['avg_response']:.1f}ms")
    return results

# ═══════════════════════════════════════════════════════════════════════════
# PART F: M/M/1 and M/M/S Queueing Theory
# ═══════════════════════════════════════════════════════════════════════════
def mm1_metrics(lam: float, mu: float) -> dict:
    """
    M/M/1 queue analytical formulas.
    lambda: arrival rate (processes/ms)
    mu:     service rate (processes/ms)
    rho:    utilization = lambda/mu (must be < 1 for stability)
    """
    rho = lam / mu
    if rho >= 1.0:
        return {"rho": rho, "stable": False,
                "L": float('inf'), "Lq": float('inf'),
                "W": float('inf'), "Wq": float('inf'),
                "P0": 0.0}
    P0  = 1 - rho                    # P(system empty)
    L   = rho / (1 - rho)            # avg number in system
    Lq  = rho**2 / (1 - rho)         # avg number in queue
    W   = 1 / (mu - lam)             # avg time in system
    Wq  = rho / (mu - lam)           # avg time in queue (waiting)
    return {"rho": rho, "stable": True,
            "L": L, "Lq": Lq, "W": W, "Wq": Wq, "P0": P0}

def mms_erlang_c(rho_per_server: float, s: int) -> float:
    """Erlang-C formula: P(all servers busy) = C(s, rho*s)."""
    a = rho_per_server * s  # total offered load
    # Compute sum_{k=0}^{s-1} (a^k / k!) + a^s / (s! * (1 - rho_per_server))
    sum_terms = sum(a**k / math.factorial(k) for k in range(s))
    last_term  = (a**s / math.factorial(s)) * (1 / (1 - rho_per_server))
    return last_term / (sum_terms + last_term)

def mms_metrics(lam: float, mu: float, s: int) -> dict:
    """
    M/M/s queue analytical formulas.
    s: number of servers
    """
    rho = lam / (s * mu)  # per-server utilization
    if rho >= 1.0:
        return {"rho": rho, "stable": False, "s": s}
    Csa = mms_erlang_c(rho, s)       # Erlang-C probability
    Lq  = Csa * rho / (1 - rho)      # avg queue length
    L   = Lq + lam / mu              # avg in system
    Wq  = Lq / lam                   # avg wait in queue
    W   = Wq + 1 / mu                # avg time in system
    P0_inv = sum((s*rho)**k / math.factorial(k) for k in range(s)) + \
             (s*rho)**s / (math.factorial(s) * (1-rho))
    P0  = 1 / P0_inv
    return {"rho": rho, "stable": True, "s": s,
            "C(s,a)": Csa, "L": L, "Lq": Lq, "W": W, "Wq": Wq, "P0": P0}

def run_queuing_theory_analysis():
    """Compute M/M/1 and M/M/S metrics across parameter ranges."""
    print("\n[QUEUING THEORY] M/M/1 and M/M/S Analysis")

    # Mean burst = 200ms, so service rate mu = 1/200 proc/ms = 5 proc/s
    # Vary arrival rate lambda
    mu = 1/200.0  # service rate per server (processes/ms)

    mm1_results = []
    rho_vals = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99]
    print("\n  M/M/1:")
    for rho in rho_vals:
        lam = rho * mu
        r = mm1_metrics(lam, mu)
        mm1_results.append({"rho": rho, "lam": lam, **r})
        if r["stable"]:
            print(f"    rho={rho:.2f}: L={r['L']:.2f} Lq={r['Lq']:.2f} "
                  f"W={r['W']:.1f}ms Wq={r['Wq']:.1f}ms P0={r['P0']:.3f}")

    mms_results = []
    print("\n  M/M/S (s=1,2,4,8) at rho_total=0.8:")
    lam = 0.8 * mu  # fixed lambda such that rho_total=0.8 for s=1
    for s in [1, 2, 4, 8]:
        r = mms_metrics(lam, mu, s)
        mms_results.append(r)
        if r["stable"]:
            print(f"    s={s}: rho_s={r['rho']:.3f} L={r['L']:.2f} "
                  f"Lq={r['Lq']:.3f} W={r['W']:.1f}ms Wq={r['Wq']:.2f}ms")

    # Vary N, M, R (system capacity) for queueing model
    print("\n  M/M/1 stability regions (N processes, M arrival window):")
    nm_queue = []
    for N in [100, 300, 500, 1000]:
        for M in [50, 100, 200]:
            lam_sim = N / M  # arrival rate (proc/ms)
            r = mm1_metrics(lam_sim, mu)
            nm_queue.append({"N":N,"M":M,"lam":lam_sim,"mu":mu, **r})
            status = "STABLE" if r["stable"] else "UNSTABLE"
            if r["stable"]:
                print(f"    N={N:5d} M={M:5d} lam={lam_sim:.4f}/ms: "
                      f"rho={r['rho']:.3f} W={r['W']:.1f}ms [{status}]")
            else:
                print(f"    N={N:5d} M={M:5d} lam={lam_sim:.4f}/ms: "
                      f"rho={r['rho']:.3f} [{status}]")

    return {"mm1": mm1_results, "mms": mms_results, "nm_queue": nm_queue}


# ── MAIN ──────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("="*65)
    print("PAPER 3 — GRID SEARCH & QUEUEING THEORY ANALYSIS")
    print("="*65)

    N_TRIALS = 25   # trials per config (increase for production)
    N_PROCS  = 200  # processes per simulation

    results = {}

    results["Q1Q2_uniform"]  = grid_search_Q1Q2(N=N_PROCS, n_trials=N_TRIALS, dist='uniform')
    results["L1L2_uniform"]  = grid_search_L1L2(N=N_PROCS, n_trials=N_TRIALS, dist='uniform')
    results["T_uniform"]     = grid_search_T(N=N_PROCS, n_trials=N_TRIALS, dist='uniform')
    results["NM_uniform"]    = grid_search_NM(n_trials=15, dist='uniform')
    results["distributions"] = compare_distributions(N=N_PROCS, n_trials=N_TRIALS)
    results["queuing"]       = run_queuing_theory_analysis()

    with open(f"{OUT}/grid_results.json", "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved: {OUT}/grid_results.json")

    # Print optimal parameters
    print("\n" + "="*65)
    print("OPTIMAL PARAMETERS FOUND:")
    q1q2 = results["Q1Q2_uniform"]
    best_tat = min(q1q2.values(), key=lambda x: x["avg_turnaround"])
    best_thr = max(q1q2.values(), key=lambda x: x["throughput"])
    best_wait= min(q1q2.values(), key=lambda x: x["avg_waiting"])
    best_resp= min(q1q2.values(), key=lambda x: x["avg_response"])
    print(f"  Min turnaround:  Q1={best_tat['Q1']}  Q2={best_tat['Q2']}  TAT={best_tat['avg_turnaround']:.1f}ms")
    print(f"  Max throughput:  Q1={best_thr['Q1']}  Q2={best_thr['Q2']}  TH={best_thr['throughput']:.2f}/s")
    print(f"  Min waiting:     Q1={best_wait['Q1']} Q2={best_wait['Q2']}  Wait={best_wait['avg_waiting']:.1f}ms")
    print(f"  Min response:    Q1={best_resp['Q1']} Q2={best_resp['Q2']}  Resp={best_resp['avg_response']:.1f}ms")
