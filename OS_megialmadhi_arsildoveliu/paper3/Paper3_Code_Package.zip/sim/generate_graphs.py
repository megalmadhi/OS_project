#!/usr/bin/env python3
"""Generate all Paper 3 visualizations."""
import json, os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D

with open("/home/claude/paper3/results/grid_results.json") as f:
    R = json.load(f)

OUT = "/home/claude/paper3/graphs"
os.makedirs(OUT, exist_ok=True)

C1="#1F3864"; C2="#2E75B6"; C3="#E6A817"; C4="#C00000"; C5="#2E8B57"
plt.rcParams.update({'font.family':'sans-serif','font.size':9,
                     'axes.spines.top':False,'axes.spines.right':False})

def save(fig, name):
    fig.tight_layout(pad=0.5)
    fig.savefig(f"{OUT}/{name}.png", dpi=160, bbox_inches='tight')
    plt.close(fig)
    print(f"  {name}.png")

# ════════════════════════════════════════════════════════════════════════════
# FIG 1: Q1×Q2 heatmaps (4 metrics)
# ════════════════════════════════════════════════════════════════════════════
q1q2 = R["Q1Q2_uniform"]
Q1_vals = sorted(set(v["Q1"] for v in q1q2.values()))
Q2_vals = sorted(set(v["Q2"] for v in q1q2.values() if v["Q2"] > v["Q1"]))

def make_grid(metric, default=np.nan):
    grid = np.full((len(Q1_vals), len(Q2_vals)), default)
    for v in q1q2.values():
        if v["Q2"] <= v["Q1"]: continue
        i = Q1_vals.index(v["Q1"])
        j = Q2_vals.index(v["Q2"])
        grid[i, j] = v[metric]
    return grid

fig, axes = plt.subplots(2, 2, figsize=(12, 9))
fig.suptitle("Figure 1 — MLFQ Grid Search: Q1 × Q2 Parameter Heatmaps\n"
             "(N=200 processes, 25 Monte Carlo trials, uniform distribution)",
             fontsize=11, fontweight='bold', color=C1)

metrics = [("avg_turnaround","Avg Turnaround (ms)","viridis_r"),
           ("avg_waiting","Avg Waiting (ms)","plasma_r"),
           ("avg_response","Avg Response (ms)","coolwarm"),
           ("throughput","Throughput (proc/s)","viridis")]

for ax, (metric, title, cmap) in zip(axes.flat, metrics):
    grid = make_grid(metric)
    im = ax.imshow(grid, cmap=cmap, aspect='auto',
                   extent=[0,len(Q2_vals),len(Q1_vals),0])
    ax.set_xticks(range(len(Q2_vals)))
    ax.set_xticklabels([str(q) for q in Q2_vals], fontsize=8)
    ax.set_yticks(range(len(Q1_vals)))
    ax.set_yticklabels([str(q) for q in Q1_vals], fontsize=8)
    ax.set_xlabel("Q2 (ms)"); ax.set_ylabel("Q1 (ms)")
    ax.set_title(title, fontsize=10, fontweight='bold')
    plt.colorbar(im, ax=ax, shrink=0.8)
    # Mark optimal
    valid = ~np.isnan(grid)
    if metric == "throughput":
        opt = np.unravel_index(np.nanargmax(grid), grid.shape)
    else:
        opt = np.unravel_index(np.nanargmin(grid), grid.shape)
    ax.plot(opt[1]+0.5, opt[0]+0.5, 'r*', markersize=14)
save(fig, "fig1_q1q2_heatmaps")

# ════════════════════════════════════════════════════════════════════════════
# FIG 2: L1×L2 heatmaps
# ════════════════════════════════════════════════════════════════════════════
l1l2 = R["L1L2_uniform"]
L1_vals = sorted(set(v["L1"] for v in l1l2.values()))
L2_vals = sorted(set(v["L2"] for v in l1l2.values()))

def make_l_grid(metric):
    grid = np.full((len(L1_vals), len(L2_vals)), np.nan)
    for v in l1l2.values():
        if v["L1"]+v["L2"] >= 95: continue
        i = L1_vals.index(v["L1"])
        j = L2_vals.index(v["L2"])
        grid[i, j] = v[metric]
    return grid

fig, axes = plt.subplots(1, 2, figsize=(12, 5))
fig.suptitle("Figure 2 — MLFQ Grid Search: L1 × L2 Time Allocation Heatmaps\n"
             "(Q1=8ms, Q2=16ms, T=50%, N=200 processes)",
             fontsize=11, fontweight='bold', color=C1)

for ax, (metric, title, cmap) in zip(axes, [
    ("avg_turnaround","Avg Turnaround (ms)","viridis_r"),
    ("avg_waiting","Avg Waiting (ms)","plasma_r")]):
    grid = make_l_grid(metric)
    im = ax.imshow(grid, cmap=cmap, aspect='auto',
                   extent=[0,len(L2_vals),len(L1_vals),0])
    ax.set_xticks(range(len(L2_vals)))
    ax.set_xticklabels([str(q) for q in L2_vals], fontsize=8)
    ax.set_yticks(range(len(L1_vals)))
    ax.set_yticklabels([str(q) for q in L1_vals], fontsize=8)
    ax.set_xlabel("L2 (ms)"); ax.set_ylabel("L1 (ms)")
    ax.set_title(title, fontsize=10, fontweight='bold')
    plt.colorbar(im, ax=ax, shrink=0.85)
    opt = np.unravel_index(np.nanargmin(grid), grid.shape)
    ax.plot(opt[1]+0.5, opt[0]+0.5, 'r*', markersize=14, label=f"Optimal: L1={L1_vals[opt[0]]}, L2={L2_vals[opt[1]]}")
    ax.legend(fontsize=8, loc='lower right')
save(fig, "fig2_l1l2_heatmaps")

# ════════════════════════════════════════════════════════════════════════════
# FIG 3: 3D surface — Turnaround vs Q1, Q2
# ════════════════════════════════════════════════════════════════════════════
fig = plt.figure(figsize=(13, 5))
fig.suptitle("Figure 3 — 3D Performance Surfaces: Turnaround & Response vs Q1, Q2",
             fontsize=11, fontweight='bold', color=C1)

for idx, (metric, title, cmap) in enumerate([
    ("avg_turnaround","Avg Turnaround (ms)","viridis"),
    ("avg_response","Avg Response (ms)","plasma")]):
    ax = fig.add_subplot(1, 2, idx+1, projection='3d')
    grid = make_grid(metric)
    X, Y = np.meshgrid(range(len(Q2_vals)), range(len(Q1_vals)))
    Z = grid.copy(); Z[np.isnan(Z)] = np.nanmax(grid)
    surf = ax.plot_surface(X, Y, Z, cmap=cmap, alpha=0.9, linewidth=0.3, edgecolor='white')
    ax.set_xticks(range(len(Q2_vals))); ax.set_xticklabels(Q2_vals, fontsize=7)
    ax.set_yticks(range(len(Q1_vals))); ax.set_yticklabels(Q1_vals, fontsize=7)
    ax.set_xlabel("Q2 (ms)", fontsize=8); ax.set_ylabel("Q1 (ms)", fontsize=8)
    ax.set_zlabel(title, fontsize=7)
    ax.set_title(title, fontsize=9, fontweight='bold')
    fig.colorbar(surf, ax=ax, shrink=0.6)
save(fig, "fig3_3d_surfaces")

# ════════════════════════════════════════════════════════════════════════════
# FIG 4: T (SJF/FCFS split) effect on all 4 metrics
# ════════════════════════════════════════════════════════════════════════════
t_data = R["T_uniform"]
T_vals  = sorted(v["T"] for v in t_data.values())
tats    = [t_data[f"T={t}"]["avg_turnaround"] for t in T_vals]
waits   = [t_data[f"T={t}"]["avg_waiting"]    for t in T_vals]
resps   = [t_data[f"T={t}"]["avg_response"]   for t in T_vals]
thputs  = [t_data[f"T={t}"]["throughput"]     for t in T_vals]

fig, axes = plt.subplots(2, 2, figsize=(12, 8))
fig.suptitle("Figure 4 — Effect of SJF/FCFS Split (T%) in Level-3 on All 4 Metrics\n"
             "(Q1=8, Q2=16, L1=25, L2=35, N=200, 25 trials)",
             fontsize=11, fontweight='bold', color=C1)

for ax, (vals, ylabel, color, title) in zip(axes.flat, [
    (tats,  "Avg Turnaround (ms)", C4, "Turnaround vs T%"),
    (waits, "Avg Waiting (ms)",    C2, "Waiting Time vs T%"),
    (resps, "Avg Response (ms)",   C3, "Response Time vs T%"),
    (thputs,"Throughput (proc/s)", C5, "Throughput vs T%")]):
    ax.plot(T_vals, vals, 'o-', color=color, lw=2, ms=7)
    ax.fill_between(T_vals, vals, alpha=0.15, color=color)
    ax.set_xlabel("T% (SJF fraction of Level-3)")
    ax.set_ylabel(ylabel); ax.set_title(title, fontweight='bold')
    ax.grid(alpha=0.3)
    # Mark optimal
    if title == "Throughput vs T%": opt_t = T_vals[np.argmax(vals)]
    else: opt_t = T_vals[np.argmin(vals)]
    ax.axvline(opt_t, color='red', ls='--', alpha=0.7, label=f"Optimal T={opt_t}%")
    ax.legend(fontsize=8)
save(fig, "fig4_T_effect")

# ════════════════════════════════════════════════════════════════════════════
# FIG 5: N processes & M arrival window effect
# ════════════════════════════════════════════════════════════════════════════
nm_data = R["NM_uniform"]
N_vals  = sorted(set(v["N"] for v in nm_data.values()))
M_colors= {50:C2, 100:C3, 200:C5}
M_vals  = [50, 100, 200]

fig, axes = plt.subplots(1, 2, figsize=(12, 5))
fig.suptitle("Figure 5 — Scalability: Throughput & Turnaround vs Process Count N\n"
             "(Q1=8, Q2=16, L1=25, L2=35, T=50%)",
             fontsize=11, fontweight='bold', color=C1)

for M in M_vals:
    ns  = sorted(v["N"] for v in nm_data.values() if v["M"]==M)
    thp = [nm_data[f"N={n}_M={M}"]["throughput"]     for n in ns]
    tat = [nm_data[f"N={n}_M={M}"]["avg_turnaround"] for n in ns]
    axes[0].plot(ns, thp, 'o-', color=M_colors[M], lw=2, ms=7, label=f"M={M}ms")
    axes[1].plot(ns, tat, 'o-', color=M_colors[M], lw=2, ms=7, label=f"M={M}ms")

for ax, (ylabel, title) in zip(axes, [
    ("Throughput (proc/s)", "Throughput vs N Processes"),
    ("Avg Turnaround (ms)", "Turnaround vs N Processes")]):
    ax.set_xlabel("N Processes"); ax.set_ylabel(ylabel)
    ax.set_title(title, fontweight='bold')
    ax.legend(); ax.grid(alpha=0.3)
save(fig, "fig5_NM_scalability")

# ════════════════════════════════════════════════════════════════════════════
# FIG 6: Distribution comparison
# ════════════════════════════════════════════════════════════════════════════
dist_data = R["distributions"]
dists = ["uniform", "exponential", "poisson"]
metrics_d = ["avg_turnaround","avg_waiting","avg_response","throughput"]
labels_d  = ["Avg Turnaround (ms)","Avg Waiting (ms)","Avg Response (ms)","Throughput (proc/s)"]

fig, axes = plt.subplots(2, 2, figsize=(12, 8))
fig.suptitle("Figure 6 — Impact of Arrival/Burst Distribution on All Metrics\n"
             "(Same MLFQ parameters; N=200, 25 trials per distribution)",
             fontsize=11, fontweight='bold', color=C1)
colors_d = [C2, C4, C5]

for ax, (metric, label) in zip(axes.flat, zip(metrics_d, labels_d)):
    vals = [dist_data[d][metric] for d in dists]
    bars = ax.bar(dists, vals, color=colors_d, alpha=0.85, edgecolor='white', linewidth=1)
    ax.set_ylabel(label); ax.set_title(label, fontweight='bold')
    ax.grid(axis='y', alpha=0.3)
    for bar, v in zip(bars, vals):
        ax.text(bar.get_x()+bar.get_width()/2, v*1.01, f"{v:.1f}", ha='center', fontsize=8, fontweight='bold')
save(fig, "fig6_distributions")

# ════════════════════════════════════════════════════════════════════════════
# FIG 7: M/M/1 — L, Lq, W, Wq vs rho
# ════════════════════════════════════════════════════════════════════════════
mm1 = [r for r in R["queuing"]["mm1"] if r["stable"]]
rhos = [r["rho"] for r in mm1]
L_vals  = [r["L"]  for r in mm1]
Lq_vals = [r["Lq"] for r in mm1]
W_vals  = [r["W"]  for r in mm1]
Wq_vals = [r["Wq"] for r in mm1]

fig, axes = plt.subplots(1, 2, figsize=(12, 5))
fig.suptitle("Figure 7 — M/M/1 Queueing Model: System Metrics vs Utilization ρ\n"
             "(Service rate μ=1/200ms, varying arrival rate λ)",
             fontsize=11, fontweight='bold', color=C1)

axes[0].plot(rhos, L_vals,  'o-', color=C2, lw=2, ms=7, label="L (system)")
axes[0].plot(rhos, Lq_vals, 's--',color=C4, lw=2, ms=7, label="Lq (queue)")
axes[0].set_xlabel("Utilization ρ = λ/μ"); axes[0].set_ylabel("Average Queue Length")
axes[0].set_title("Queue Length L and Lq vs ρ", fontweight='bold')
axes[0].legend(); axes[0].grid(alpha=0.3)
axes[0].axvline(0.8, color='red', ls=':', alpha=0.7, label='ρ=0.8 (design limit)')

axes[1].plot(rhos, W_vals,  'o-', color=C2, lw=2, ms=7, label="W (system)")
axes[1].plot(rhos, Wq_vals, 's--',color=C4, lw=2, ms=7, label="Wq (queue)")
axes[1].set_xlabel("Utilization ρ = λ/μ"); axes[1].set_ylabel("Average Wait Time (ms)")
axes[1].set_title("Wait Time W and Wq vs ρ", fontweight='bold')
axes[1].legend(); axes[1].grid(alpha=0.3)
axes[1].set_yscale('log')
save(fig, "fig7_mm1_metrics")

# ════════════════════════════════════════════════════════════════════════════
# FIG 8: M/M/S — comparison of s=1,2,4,8 servers
# ════════════════════════════════════════════════════════════════════════════
mms = [r for r in R["queuing"]["mms"] if r["stable"]]
s_vals  = [r["s"] for r in mms]
Wq_mms  = [r["Wq"] for r in mms]
Lq_mms  = [r["Lq"] for r in mms]
rho_mms = [r["rho"] for r in mms]

fig, axes = plt.subplots(1, 2, figsize=(12, 5))
fig.suptitle("Figure 8 — M/M/S Queue: Effect of Server Count s on Waiting Time\n"
             "(Fixed total load λ=0.8μ, μ=1/200ms)",
             fontsize=11, fontweight='bold', color=C1)

colors_s = [C4, C3, C2, C5]
axes[0].bar([str(s) for s in s_vals], Wq_mms, color=colors_s, alpha=0.9, edgecolor='white')
axes[0].set_xlabel("Number of Servers s"); axes[0].set_ylabel("Avg Queue Wait Wq (ms)")
axes[0].set_title("Queue Wait vs Server Count", fontweight='bold'); axes[0].grid(axis='y', alpha=0.3)
for i,(s,wq) in enumerate(zip(s_vals,Wq_mms)):
    axes[0].text(i, wq+1, f"{wq:.1f}ms", ha='center', fontsize=9, fontweight='bold')

axes[1].bar([str(s) for s in s_vals], Lq_mms, color=colors_s, alpha=0.9, edgecolor='white')
axes[1].set_xlabel("Number of Servers s"); axes[1].set_ylabel("Avg Queue Length Lq")
axes[1].set_title("Queue Length vs Server Count", fontweight='bold'); axes[1].grid(axis='y', alpha=0.3)
for i,(s,lq) in enumerate(zip(s_vals,Lq_mms)):
    axes[1].text(i, lq+0.01, f"{lq:.3f}", ha='center', fontsize=9, fontweight='bold')
save(fig, "fig8_mms_comparison")

# ════════════════════════════════════════════════════════════════════════════
# FIG 9: Optimal parameter summary — radar/spider chart
# ════════════════════════════════════════════════════════════════════════════
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
fig.suptitle("Figure 9 — Optimal MLFQ Parameters: Summary Across All Search Dimensions",
             fontsize=11, fontweight='bold', color=C1)

# Q1/Q2 optimal summary
q_data = list(q1q2.values())
configs = [f"Q1={v['Q1']}\nQ2={v['Q2']}" for v in q_data[:8]]
tats_q  = [v["avg_turnaround"] for v in q_data[:8]]
resps_q = [v["avg_response"]   for v in q_data[:8]]

x = np.arange(len(configs)); w = 0.4
axes[0].bar(x - w/2, [t/1000 for t in tats_q], w, color=C2, alpha=0.85, label="Turnaround (s)")
axes[0].bar(x + w/2, [r/1000 for r in resps_q], w, color=C4, alpha=0.85, label="Response (s)")
axes[0].set_xticks(x); axes[0].set_xticklabels(configs, fontsize=7)
axes[0].set_ylabel("Time (seconds)"); axes[0].set_title("First 8 Q1/Q2 Configs", fontweight='bold')
axes[0].legend(); axes[0].grid(axis='y', alpha=0.3)

# T sweep summary
T_opt_data = [t_data[f"T={t}"] for t in T_vals]
axes[1].plot(T_vals, [v["avg_turnaround"]/1000 for v in T_opt_data], 'o-', color=C4, lw=2, ms=6, label="Turnaround (s)")
axes[1].plot(T_vals, [v["avg_waiting"]/1000     for v in T_opt_data], 's--',color=C2, lw=2, ms=6, label="Waiting (s)")
axes[1].plot(T_vals, [v["avg_response"]/1000    for v in T_opt_data], '^-.',color=C3, lw=2, ms=6, label="Response (s)")
ax2 = axes[1].twinx()
ax2.plot(T_vals, [v["throughput"] for v in T_opt_data], 'D:', color=C5, lw=1.5, ms=5, label="Throughput")
axes[1].set_xlabel("T% (SJF in Level-3)"); axes[1].set_ylabel("Time (seconds)")
ax2.set_ylabel("Throughput (proc/s)", color=C5)
axes[1].set_title("All Metrics vs T%", fontweight='bold'); axes[1].legend(fontsize=8); axes[1].grid(alpha=0.3)
save(fig, "fig9_optimal_summary")

# ════════════════════════════════════════════════════════════════════════════
# FIG 10: M/M/1 P0, Pn probabilities
# ════════════════════════════════════════════════════════════════════════════
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
fig.suptitle("Figure 10 — M/M/1 State Probabilities and Stability Analysis",
             fontsize=11, fontweight='bold', color=C1)

# P(n) for different rho
rho_show = [0.3, 0.5, 0.7, 0.9]
n_states = range(0, 20)
colors_r = [C2, C3, C4, '#8B0000']
for rho, col in zip(rho_show, colors_r):
    pn = [(1-rho)*rho**n for n in n_states]
    axes[0].plot(list(n_states), pn, 'o-', color=col, lw=1.5, ms=5, label=f"ρ={rho}")
axes[0].set_xlabel("n (number in system)"); axes[0].set_ylabel("P(N=n)")
axes[0].set_title("State Probabilities P(N=n) for various ρ", fontweight='bold')
axes[0].legend(); axes[0].grid(alpha=0.3); axes[0].set_yscale('log')

# L and W vs rho (highlight design region)
rho_fine = np.linspace(0.01, 0.99, 200)
L_fine   = rho_fine / (1 - rho_fine)
W_fine   = 1 / (1/200.0 * (1 - rho_fine))  # W in ms
axes[1].plot(rho_fine, L_fine, color=C2, lw=2, label="L (queue length)")
ax2r = axes[1].twinx()
ax2r.plot(rho_fine, W_fine/1000, color=C4, lw=2, ls='--', label="W (system time, s)")
axes[1].axvspan(0, 0.8, alpha=0.1, color='green', label="Stable design region (ρ<0.8)")
axes[1].axvline(0.8, color='red', ls=':', lw=1.5)
axes[1].set_xlabel("Utilization ρ"); axes[1].set_ylabel("Avg Queue Length L", color=C2)
ax2r.set_ylabel("Avg System Time W (s)", color=C4)
axes[1].set_title("L and W vs ρ — Design Region", fontweight='bold')
axes[1].set_xlim(0, 0.99); axes[1].set_ylim(0, 30)
axes[1].grid(alpha=0.3)
save(fig, "fig10_mm1_probabilities")

print("\nAll 10 figures generated.")
