=================================================================
PAPER 3 — Code Package
Optimization of Multilevel Feedback Queue Scheduling
and Queueing Models Using Simulation and Analytical Techniques
CEN/SWE Operating Systems 2025-2026
=================================================================

REQUIREMENTS:
  Python 3.9+  |  pip install numpy scipy matplotlib

HOW TO RUN:
  1. Single simulation (Q1=8 Q2=16 L1=25 L2=35 T=50 N=200 M=100):
       python3 sim/mlfq_simulator.py 8 16 25 35 50 200 100

  2. Full grid search over all 5 parameters (~5 min):
       python3 sim/grid_search.py

  3. Regenerate all 10 graphs from saved results:
       python3 sim/generate_graphs.py

KEY FILES:
  sim/mlfq_simulator.py   Core 3-level MLFQ engine + Monte Carlo
  sim/grid_search.py      Grid search + M/M/1 + M/M/S queueing theory
  sim/generate_graphs.py  All 10 paper figures
  results/grid_results.json  All raw data (875+ config averages)
=================================================================
